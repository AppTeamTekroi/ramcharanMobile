import 'package:flutter/material.dart';

class AppColors {
  /// White
  static const Color white = Color(0xFFFFFFFF);
  /// icons
  static const Color icons = Colors.blueAccent;
  /// background
   static Color primary = Color(0xFFED2327);

  static Color secondary = Color(0xFFF1F1F1);

  //static Color primary = Colors.blue.shade900;

  static Color text = Color(0xFF6D6E71);
  static Color black = Color(0xFF090A0A);

  static Color container = Color(0xFFF4F0DC);

}
//0xFFCBD5E1