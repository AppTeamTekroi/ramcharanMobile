import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:get/get.dart';

import '../Login/login_controller.dart';
import 'userController.dart';
import '../ui/CommonBackground.dart';
import '../ui/assets/app_assets.dart';
import '../ui/color/appColor.dart';
import '../ui/headers.dart';
import '../ui/widgets/CommonWidget.dart';
import '../ui/widgets/richtext.dart';
import 'controllers/farmerController.dart';
import 'farmerDetails.dart';


class Farmerlist extends StatefulWidget {
  final bool fromCrop;
  const Farmerlist({super.key, required this.fromCrop});

  @override
  State<Farmerlist> createState() => _FarmerlistState();
}

class _FarmerlistState extends State<Farmerlist> {
  UserController upc = Get.put(UserController());
  FarmerController farmer = Get.put(FarmerController());
  @override
  @override
  void initState() {
    super.initState();
    farmer.farmerList(context);

  }

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;
    return  Scaffold(
      backgroundColor: Color(0xFFF1F1F1),

      appBar: AppBar(
        scrolledUnderElevation: 0,
        automaticallyImplyLeading: false,
        toolbarHeight: 120,
        // leadingWidth: 40,
        // iconTheme: const IconThemeData(
        //   color: Colors.grey, // ✅ makes the back arrow white
        // ),
        backgroundColor: AppColors.white,
        title: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: Get.back,
                  child: Padding(
                    padding: const EdgeInsets.only(right: 8.0),
                    child: Icon(Icons.arrow_back_ios,color: AppColors.black,),
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Farmers Directory",
                        style: GoogleFonts.openSans(fontSize: 20,fontWeight: FontWeight.w500,wordSpacing: 0)
                    ),
                    Text("Ramcharan Oil Industries",
                        style: GoogleFonts.openSans(fontSize: 12,fontWeight: FontWeight.w500,wordSpacing: 0,color: Colors.grey)
                    ),

                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 8.0),
                  child: Container(
                    padding: EdgeInsets.all(5),
                    decoration: BoxDecoration(color: AppColors.primary,
                        borderRadius: BorderRadius.circular(8)
                    ),
                    child: Icon(Icons.add,color: AppColors.white,),
                  ),
                )
              ],
            ),
            SizedBox(height: 15,),
            Container(
              margin: EdgeInsets.only(right: 0, left: 0,bottom: 12),

              decoration: BoxDecoration(
                color: Color(0xFFF1F1F1),
                borderRadius: BorderRadius.circular(10),
                // border: Border.all(
                //     color: AppColors.secondary, width: 1),
              ),
              child: Padding(
                padding: const EdgeInsets.only(left: 10, right: 5),
                child: TextField(

                  decoration: InputDecoration(

                      hintText: "Search Name or Phone...",
                      hintStyle: GoogleFonts.openSans(fontSize: 18, fontWeight: FontWeight.w400,color:AppColors.text),
                      border: InputBorder.none,
                      //suffixIcon:
                      // Padding(
                      //   padding: const EdgeInsets.only(top: 15),
                      //   child: Padding(
                      //     padding: const EdgeInsets.only(left: 8, right: 8),
                      //     child: Text(
                      //       'Search',
                      //       style: TextStyle(fontSize: 15),
                      //     ),
                      //   ),
                      // )
                      prefixIcon: Icon(Icons.search,color:AppColors.text)


                  ),

                  onChanged: (val) {

                    // Use the original full list (not already filtered one)
                    if (val.isNotEmpty && val.length > 2) { // start search after 3+ chars (optional)
                      final query = val.toLowerCase();

                      farmer.filteredList.value = farmer.opplist
                          .where((item) {
                        final name = item["farmer_name"]?.toLowerCase() ?? '';
                        final phone = item["farmer_mobile"].toString() ?? '';
                        return name.contains(query) || phone.contains(query);
                      })
                          .toList();
                    } else {
                      farmer.filteredList.value = farmer.opplist;
                    }

                    farmer.filteredList.refresh();
                  },




                  //  customerController.searchProductByName(val);

                ),
              ),

              // actions: [
              //  // if (widget.customerId != null)
              //     Padding(
              //       padding: const EdgeInsets.only(right: 15),
              //       child: GestureDetector(
              //         child: FaIcon(
              //           FontAwesomeIcons.barcode,
              //           color: Colors.black,
              //         ),
              //       ),
              //     ),
              //  // if (widget.customerId != null)
              //     Padding(
              //       padding: const EdgeInsets.only(right: 10),
              //       child: GestureDetector(
              //         onTap: () {
              //           //   Get.to(() => CartScreen(customerId: widget.customerId));
              //         },
              //         child: Icon(
              //           Icons.shopping_cart_outlined,
              //           color: Colors.black,
              //         ),
              //       ),
              //     ),
              // ],
            ),
          ],
        ),
      ),
      body:  Padding(
        padding: const EdgeInsets.all(8.0),
        child: Obx(()=>ListView.builder(
            itemCount: farmer.filteredList.length,
            itemBuilder: (context,index) {
              final data = farmer.filteredList[index];

              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 5.0,horizontal: 8),
                child:  GestureDetector(
              onTap: (){
              if(widget.fromCrop == true) {
              Get.back(result: data);
              }
              },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 15.0,vertical: 12),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        // border: Border.all(
                        //     color: Colors.grey.shade300, width: 1),
                        color: Colors.white
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(radius: 22,child: Image.asset("lib/ui/assets/images/farmerIcon.png"),),
                        SizedBox(width: 20,),
                        Expanded(
                          child: Column(
                            spacing: 3,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                               Row(
                                 children: [
                                   Text(data['farmer_name'],style: GoogleFonts.roboto(fontWeight: FontWeight.w500,fontSize: 15),),
                                   // Container(
                                   //   height: height * 0.025,
                                   //   width: width * 0.2,
                                   //   decoration: BoxDecoration(
                                   //       color: Color.fromARGB(255, 255, 232, 157),
                                   //       //  Color(0Xff30CB00),
                                   //       borderRadius: BorderRadius.circular(12)),
                                   //   child: Center(
                                   //     child: Text('Pending',
                                   //         style: TextStyle(
                                   //             fontSize: height * 0.01,
                                   //             color: Colors.red,
                                   //             fontWeight: FontWeight.bold)),
                                   //   ),
                                   // ),
                                   Spacer(),
                                   GestureDetector(
                                       onTap: (){
                                         Get.to(()=>Farmerdetails(data:data, farmerId: data['id']));
                                       },
                                       child: Icon(Icons.arrow_forward_ios,size: 12,color: AppColors.text,)
                                   ),
                                 ],
                               ),

                                CommonRichText(
                                  label: 'Farmer Code',
                                  value: data['farmer_code'].toString(),
                                ),
                                CommonRichText(
                                  label: 'Mobile',
                                  value: data['farmer_mobile'].toString(),
                                ),
                               Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                 children: [
                                   Text('⚲  ${data['district']}'),
                                 Padding(
                                   padding: const EdgeInsets.only(right: 8.0),
                                   child: Container(
                                     padding: EdgeInsets.all(8),
                                     decoration: BoxDecoration(color: Colors.red.shade50,
                                         borderRadius: BorderRadius.circular(15)
                                     ),
                                     child: Icon(Icons.call,color: AppColors.primary,size: 18,),
                                   ),
                                 )
                               ],)
                              ],
                            ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
        ),
      )


    );
  }
}