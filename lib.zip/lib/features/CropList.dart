import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:shimmer/shimmer.dart';
import 'package:ramcharan/features/controllers/farmerController.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../ui/color/appColor.dart';
import '../ui/widgets/richtext.dart';
import 'farmerDetails.dart';

class Croplist extends StatefulWidget {
  const Croplist({super.key});

  @override
  State<Croplist> createState() => _CroplistState();
}

class _CroplistState extends State<Croplist> {

  FarmerController qc = Get.put(FarmerController());
  String currentDate = DateFormat('dd-MM-yyyy').format(DateTime.now());
  final ScrollController _scrollController = ScrollController();

  var totalrecords = "0".obs;
  var filterrecords = '0'.obs;
  var totalAmount = "₹0.00".obs;
  var sales_employee = "".obs;

  @override

  void initState() {

    super.initState();

    qc.searchQuery.value = '';

    _fetchData();

  }

  Future<void> _fetchData() async {

    await qc.cropList(context);

  }
  Future<void> _launchURL(url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $url");
    }
  }

    @override
    Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final height = MediaQuery.sizeOf(context).height;
    return Scaffold(
        backgroundColor: Colors.grey[200],
    appBar: AppBar(
    backgroundColor: AppColors.white,

    title: Text(
    "FFB Collection",
    style: TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.bold,
    ),
    ),
    ),

    body: Column(children: [
    // Container(
    // margin: EdgeInsets.all(MediaQuery.of(context).size.width * 0.03),
    // height: height * 0.18,
    // width: MediaQuery.of(context).size.width * 0.94,
    // decoration: BoxDecoration(
    // color: Colors.white, borderRadius: BorderRadius.circular(12)),
    // child: Padding(
    // padding: EdgeInsets.symmetric(horizontal: height * 0.015),
    // child: Column(
    // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    // children: [
    // Obx(()=> SizedBox(
    // height: height * 0.08,
    // child: Padding(
    // padding: EdgeInsets.symmetric(horizontal: height * 0.015),
    // child: Row(
    // mainAxisAlignment: MainAxisAlignment.spaceAround,
    // // crossAxisAlignment: CrossAxisAlignment.stretch,
    // children: [
    // Column(
    // mainAxisAlignment: MainAxisAlignment.center,
    // crossAxisAlignment: CrossAxisAlignment.start,
    // children: [
    // const Text(
    // 'Total Amount',
    // style: TextStyle(
    // color:
    // Color.fromARGB(255, 147, 147, 147)),
    // ),
    // Text(
    // totalAmount.value,
    // style: TextStyle(
    // fontSize: height * 0.025,
    // fontWeight: FontWeight.bold),
    // ),
    // ],
    // ),
    // const Spacer(),
    // Column(
    // mainAxisAlignment: MainAxisAlignment.center,
    // crossAxisAlignment: CrossAxisAlignment.center,
    // children: [
    // const Text('Records',
    // style: TextStyle(
    // color: Color.fromARGB(
    // 255, 147, 147, 147))),
    // Text(
    // totalrecords.value,
    // style: TextStyle(
    // fontSize: height * 0.025,
    // fontWeight: FontWeight.bold),
    // ),
    // ],
    // ),
    // const Spacer(),
    // // Column(
    // //   mainAxisAlignment: MainAxisAlignment.center,
    // //   crossAxisAlignment: CrossAxisAlignment.end,
    // //   children: [
    // //     const Text(
    // //       'UnApproved',
    // //       style: TextStyle(
    // //           color:
    // //           Color.fromARGB(255, 147, 147, 147)),
    // //     ),
    // //     Text(
    // //       filterrecords,
    // //       style: TextStyle(
    // //           fontSize: height * 0.025,
    // //           fontWeight: FontWeight.bold),
    // //     ),
    // //   ],
    // // ),
    // ],
    // ),
    //
    // ),
    // ),
    // ),
    // const Divider(
    // color: Color.fromARGB(255, 193, 193, 193),
    // height: 2,
    // ),
    // Row(
    // crossAxisAlignment: CrossAxisAlignment.center,
    // mainAxisAlignment: MainAxisAlignment.spaceAround,
    // // crossAxisAlignment: CrossAxisAlignment.stretch,
    // children: [
    // Column(
    // mainAxisAlignment: MainAxisAlignment.center,
    // crossAxisAlignment: CrossAxisAlignment.start,
    // children: [
    // Row(
    // children: [
    // Text(
    // 'This Year',
    // style: TextStyle(
    // fontWeight: FontWeight.bold,
    // fontSize: height * 0.02),
    // ),
    // const Icon(CupertinoIcons.pen)
    // ],
    // ),
    // const Text(
    // "Starting date - ending date",
    // style: TextStyle(
    // color: Colors.grey,
    // fontWeight: FontWeight.bold,
    // fontSize: 12),
    // ),
    // ],
    // ),
    // const Spacer(),
    // Row(
    // mainAxisAlignment: MainAxisAlignment.center,
    // children: [
    // const Icon(
    // Icons.filter_alt_rounded,
    // color: Colors.grey,
    // size: 20,
    // ),
    // SizedBox(
    // width: 10,
    // ),
    // const Icon(
    // CupertinoIcons.search,
    // color: Colors.grey,
    // size: 20,
    // ),
    // ],
    // )
    // ],
    // ),
    // ],
    // ),
    // ),
    // ),
    Expanded(child: Obx(() {
    if (qc.isLoading.value) {
    return const Center(child: CircularProgressIndicator());
    } else if (qc.errorMessage.value.isNotEmpty) {
    return Center(child: Text(qc.errorMessage.value));
    } else {
    if (qc.cropsData.isEmpty) {
    return Center(
    child: Text(
    'No records Found',
    style: TextStyle(fontSize: 18),
    ),
    );
    }
    return ListView.builder(
    controller: _scrollController,
    itemCount:
    qc.cropsData.length,
    itemBuilder: (context, index) {
    if (index == qc.cropsData.length) {
    return Center(child: CircularProgressIndicator());
    }
    final item = qc.cropsData[index];
    return  Padding(
    padding:  EdgeInsets.symmetric(vertical: 5,horizontal: Get.height * 0.015),
    child:InkWell(
    onTap: () {
    // print('Order Card Pressed');
    // if (widget.) {
    // Get.back(result: {
    // 'enqNo': item['opportunity_no_prefix'] ?? null,
    // });
    // }else {
    // Navigator.push(
    // context,
    // MaterialPageRoute(9876543290
    // builder: (context) =>
    // EnquiryDetailsScreen(
    // oppId: (item['id']).toString(),
    // page: 'Enquiry',),
    // ),
    // );
    // }
    },
    child:Card(
    clipBehavior: Clip.antiAliasWithSaveLayer,
    shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(15)),
    child: Container(
    color: Colors.white,
    child: Padding(
    padding:  EdgeInsets.symmetric(vertical: 5,horizontal: Get.height * 0.015),
    child:Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    Row(
    mainAxisAlignment:
    MainAxisAlignment.spaceBetween,
    children: [
    Text(
    'Receipt No: ${item["receipt_id"]}',
    //  "Doc No: ${item["id"]}",
    style: TextStyle(
    fontSize: 15,
    fontWeight: FontWeight.w500,
    color: AppColors.primary),
    ),
    // Text(
    //   "Code: ${item["customer_webid"]}",
    //   style: TextStyle(
    //       fontSize: 15,
    //       fontWeight: FontWeight.w500,
    //       color: AppColors.blues),
    // ),
    // Container(
    //   height: height * 0.020,
    //   width: width * 0.2,
    //   decoration: BoxDecoration(
    //       color: item['status_id'] == 1?
    //       Color.fromARGB(255, 255, 232, 157):
    //       Color(0Xff30CB00),
    //       borderRadius: BorderRadius.only(
    //           topRight: Radius.circular(20),
    //           bottomLeft: Radius.circular(10))),
    //   child: Center(
    //     child:
    //
    //     Text(item['status_id'] == 1 ? 'Open' : 'Close',
    //         style: TextStyle(
    //             fontSize: height * 0.009,
    //             color: item['status_id'] == 1 ?Colors.red:Colors.white,
    //             fontWeight: FontWeight.bold)),
    //     // Text(
    //     //     item['status_name'] ?? '- -',
    //     //     style: TextStyle(
    //     //         fontSize: height * 0.009,
    //     //         color: item['status_id'] == 1?Colors.red:Colors.white,
    //     //         fontWeight: FontWeight.bold)),
    //   ),
    // ),
    // Container(
    // height: height * 0.025,
    // width: width * 0.2,
    // decoration: BoxDecoration(
    // color: item['status_id'] == 1?
    // Color.fromARGB(255, 255, 232, 157):Colors.lightGreen.shade200,
    // //  Color(0Xff30CB00),
    // borderRadius: BorderRadius.only(
    // topRight: Radius.circular(20),
    // bottomLeft: Radius.circular(10))),
    // child: Center(
    // child: Text(
    // item['status_id'] == 1 ? 'Open':'Close',
    // style: TextStyle(
    // fontSize: height * 0.01,
    // color: item['status_id'] == 1?Colors.red:Colors.black,
    // fontWeight: FontWeight.bold)),
    // ),
    // ),


      (item["pdf"] != null || item["pdf"] == "") ?
        GestureDetector(
          onTap: () {
            if (item[
            "pdf"] != null && item[
            "pdf"] != '') {
              _launchURL(item[
              "pdf"]);
            }
          },
          child: Row(
            children: [
              // const Icon(
              //   Icons.file_copy_outlined,
              //   color: Color(0xFFC09500),
              // ),
              // const SizedBox(width: 8),
              Text(
                'View PDF', style: TextStyle(
                  color: Color(0xFFC09500), fontWeight: FontWeight.w500),
                // style: CommonWidget.,
              ),
            ],
          ),
        ):GestureDetector(
        onTap: () {
          if (item[
          "pdf"] != null && item[
          "pdf"] != '') {
            _launchURL(item[
            "pdf"]);
          }
        },
        child: Row(
          children: [
            // const Icon(
            //   Icons.file_copy_outlined,
            //   color: Color(0xFFC09500),
            // ),
            // const SizedBox(width: 8),
            Text(
              'Generate PDF', style: TextStyle(
                color: Color(0xFFC09500), fontWeight: FontWeight.w500),
              // style: CommonWidget.,
            ),
          ],
        ),
      ),




    ],
    ),
    // CommonRichText(
    //   label: 'Doc No: ',
    //   value: item["doc_no"] ?? '- -',
    // ),
    // GestureDetector(
    //   onTap: () async {
    //     // await customerController.fetchUserID(
    //     //     context,
    //     //     itemId); // Fetch the details
    //     // Get.to(() => CustomerEditscreen());
    //   },
    //   child: Row(
    //     children: [
    //       // Text(
    //       //   "Edit",
    //       //   style: TextStyle(
    //       //       fontSize: 14,
    //       //       // fontWeight: FontWeight.w500,
    //       //       color: AppColors.blues),
    //       // ),
    //       // Icon(
    //       //   Icons.edit,
    //       //   color: AppColors.blues,
    //       //   size: 14,
    //       // )
    //     ],
    //   ),
    // )

    Divider(),


    CommonRichText(
    label: 'Farmer Name: ',
    value: item["farmer_name"] ?? '',
    ),
   


      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('Driver Name'),
          Text((item["driver_name"]?.toString()) ?? '- -'),
        ],
      ), Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('Driver Mobile'),
          Text((item["driver_mobile"]?.toString()) ?? '- -'),
        ],
      ), Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('Vehical No'),
          Text((item["vehicle_no"]?.toString()) ?? '- -'),
        ],
      ),




      // Row(
      //   mainAxisAlignment:
      //   MainAxisAlignment
      //       .spaceBetween,
      //   children: [
      //     const Text(
      //         'Variety'),
      //     Text(item[
      //     "variety"] ?? '- -'
      //
      //     ),
      //
      //
      //   ],
      // ),

    // Row(
    // mainAxisAlignment:
    // MainAxisAlignment
    //     .spaceBetween,
    // children: [
    // const Text(
    // 'Valid Till'),
    // Text(item[
    // "valid_till"] ?? '- -'
    //
    // ),
    //
    //
    // ],
    // ),
    // Row(
    // mainAxisAlignment:
    // MainAxisAlignment
    //     .spaceBetween,
    // children: [
    // const Text(
    // 'Quantity'),
    // Text((item[
    // "total_quantity"]).toString() ?? '- -'
    //
    // ),
    //
    //
    // ],
    // ),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('Gross Wt'),
          Text((item["gross_wt"]?.toString()) ?? '- -'),
        ],
      ),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('Tare Wt'),
          Text((item["tare_wt"]?.toString()) ?? '- -'),
        ],
      ),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('Net Wt'),
          Text((item["net_wt"]?.toString()) ?? '- -'),
        ],
      ),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('Rejection Wt'),
          Text((item["rejection_wt"]?.toString()) ?? '- -'),
        ],
      ),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text('Final Wt'),
          Text((item["final_wt"]?.toString()) ?? '- -'),
        ],
      ),

      // Row(
      //   mainAxisAlignment:
      //   MainAxisAlignment
      //       .spaceBetween,
      //   children: [
      //     const Text(
      //         'Recorded On'),
      //     Text(item[
      //     "created_at"] ?? '- -'
      //
      //     ),
      //
      //
      //   ],
      // ),


      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text("Details➤",style: TextStyle(fontSize: 14,color: Colors.grey,),

          ),
          Text(item[
          "created_at"] ?? '- -'

          ),
        ],
      ),
      // GestureDetector(
      //   onTap: (){
      //    //  await qc.cropDetails(context,item['farmer_id']);
      //    // final detail = qc.cropData.value;
      //     Get.to(()=> Farmerdetails(data:item, farmerId: item['farmer_id']));
      //   },
      //   child: Text('Details ➤',
      //     style: TextStyle(
      //         fontSize: 15,
      //         color: Colors.red[700],
      //         fontWeight: FontWeight.w500
      //     ),
      //   ),
      // ),

    // Row(
    // mainAxisAlignment:
    // MainAxisAlignment
    //     .spaceBetween,
    // children: [
    // const Text(
    // 'Placed By'),
    // Text((item[
    // "user_name"]) ?? '- -',style: TextStyle(color: Colors.blue[900]),
    //
    // ),
    //
    //
    // ],
    // ),

    // Row(
    //   mainAxisAlignment:
    //   MainAxisAlignment.spaceBetween,
    //   children: [
    //     // CommonRichText(
    //     //   label: 'Sales Emp: ',
    //     //   value: item["sales_emp_name"] ?? '- -',
    //     // ),
    //
    //     Text(
    //       "📞 ${item["contact_id"] ?? '- -'}",
    //       style: TextStyle(
    //         fontSize: 14,
    //         color: Colors.green[900],
    //       ),
    //     ),

    // CommonRichText(
    //   label: 'Term: ',
    //   value: item["payment_term"] ?? '- -',
    // ),
    // CommonRichText(
    //   label: 'Remarks: ',
    //   value: item["remarks"] ?? '- -',
    // ),
    // CommonRichText(
    //   label: 'Tax: ',
    //   value: item["taxes"] ?? '- -',
    // ),

    // GestureDetector(
    //   onTap: () {},
    //   child: Row(
    //     children: [
    //       Text(
    //         "Details",
    //         style: TextStyle(
    //             fontSize: 14,
    //             // fontWeight: FontWeight.w500,
    //             color: Colors.grey),
    //       ),
    //       Icon(
    //         Icons.arrow_forward_ios_outlined,
    //         color: Colors.grey,
    //         size: 14,
    //       )
    //     ],
    //   ),
    // )

    ],
    ),
    ),


    ),
    ),
    ),
    );

    });
    }
    })
    ),
    ]));
    }
    }


