import 'dart:developer';
import 'dart:ffi';
import 'dart:io';
// import 'package:mobile_scanner/mobile_scanner.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:http/http.dart' as http;
import 'package:quickalert/quickalert.dart';
import 'dart:convert';
import '../Login/login_controller.dart';
import '../core/API/URLConst.dart';
import '../core/headerfiles.dart';
import '../ui/loading.dart';
import '../ui/widgets/aadharExtraction.dart';
import 'dashboard.dart';
import 'userController.dart';
import '../ui/Buttons/button.dart';
import '../ui/CommonBackground.dart';
import '../ui/assets/app_assets.dart';
import '../ui/color/appColor.dart';
import '../ui/headers.dart';
import '../ui/widgets/CommonWidget.dart';
import '../ui/widgets/add_address_widget.dart';
import '../ui/widgets/richtext.dart';
import 'controllers/farmerController.dart';
import 'package:image/image.dart' as img;
import 'package:xml/xml.dart' as xml;

class FarmerRegistration extends StatefulWidget {
  const FarmerRegistration({super.key});

  @override
  State<FarmerRegistration> createState() => _EquipmentScreenState();
}

class _EquipmentScreenState extends State<FarmerRegistration> {
  bool isDropdownOpen = false;

  final _formKey = GlobalKey<FormState>();
  bool advanceRequired = false;
  bool isGroup = false;
  bool isSelf = false;
  var isKisan = true.obs;
  var isLand = true.obs;
  List<dynamic> landdetails = [].obs;

  TextEditingController state = TextEditingController(text: "Telangana");
  TextEditingController name = TextEditingController();
  TextEditingController aadhar = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  final RxList<dynamic> address = <dynamic>[].obs;
  String? selectedMandal;
  String? selectedVillage;
  int? selectedMandalId;
  int? selectedVillageId;
  String? selectedCenter;
  String? selectedDistrict;
  int? selectedDistrictId;

  TextEditingController accountNumber = TextEditingController();
  TextEditingController bankName = TextEditingController();
  TextEditingController ifsc = TextEditingController();

  // TextEditingController survey = TextEditingController();
  // TextEditingController acer = TextEditingController();
  // TextEditingController quality = TextEditingController();
  final TextEditingController passbookController = TextEditingController();
  bool isChecked = false;
  FarmerController cc = Get.put(FarmerController());
  String? selectedMode;

  // List<String> mandal = [
  //   'Adilabad Rural',
  //   'Adilabad Urban',
  //   'Bazarhatnoor',
  //   'Bela',
  //   'Bheempoor'
  // ];
  List<String> modes = [
    'Adilabad',
    'Hanumakonda',
    'Jayashankar',
    'Jogulamba',
    'Kamareddy'
  ];

  void clear() {
    name.clear();
    phoneController.clear();
    aadhar.clear();
    passbookController.clear();
    landdetails.clear();
    selectedDistrict = null;
    selectedMandal = null;
    // selectedvariety = null;
    isChecked = false;
    isKisan.value = true;
    isLand.value = true;
  }

  var errorValue = false.obs;
  String errorMsg = "";
  Future<void> registerFarmer() async {
    // ✅ Validate fields before posting

    LoadingOverlay.show('Processing ...');
    // ${URLConst.baseURL}
    final url = Uri.parse("${URLConst.baseURL}farmer-register");

    final body = {
      "farmer_name": name.text.trim(),
      "farmer_mobile": phoneController.text.trim(),
      "aadhaar_no": aadhar.text.trim(),
      "mandal": selectedMandal ?? "",
      "district": selectedDistrict ?? "",
      "village": selectedVillage ?? "",
      "bank_name": bankName.text.trim(),
      "account_no": accountNumber.text.trim(),
      "ifsc_code": ifsc.text.trim(),
      "is_passbook": isChecked ? "Yes" : "No",
      "passbook_number": isChecked ? passbookController.text.trim() : "",
      "collection_centre": selectedCenter,
      "lands": landdetails.map((landItem) {
        return {
          "land_name": landItem["name"] ?? "",
          "variety": landItem["community"] ?? "",
          "acers": landItem["acre"] ?? "",
          "quality_grade": landItem["quality"] ?? "",
          "village": landItem["village"] ?? "",
          "mandal": landItem["mandal"] ?? "",
          "district": landItem["district"] ?? "",
          "survey_no": landItem["survey_no"] ?? ''
        };
      }).toList(),
    };

    final headers = await ApiHelper.getHeaders();
    print("Registration Posting Data $body");

    try {
      final response = await http.post(
        url,
        headers: headers,
        body: jsonEncode(body),
      );
      final result = jsonDecode(response.body); // now it's a Map
      LoadingOverlay.hide();

      if (response.statusCode == 200) {
        print("✅ Farmer Registered Successfully");
        print(response.body);
        if (result['success'] == true) {
          CommonStyles.showSnackbar(
            status: result['success'],
            message:
                "Farmer registered successfully!\n Farmer Code :${result['farmer_code']}",
          );
          Get.offAll(() => HomeScreen());
          // clear();
        }
      } else {
        print("❌ Failed: ${response.statusCode}");
        print(response.body);

        CommonStyles.showSnackbar(
          status: result['success'],
          message: result['message'],
        );
      }
    } catch (e) {
      QuickAlert.show(
        context: Get.context!,
        type: QuickAlertType.error,
        title: "Error",
        text: "Something went wrong. Please try again.",
      );
    }
  }

  Future<void> _scanBin() async {
    // try {
    //   await showDialog(
    //     context: context,
    //     builder: (context) {
    //       return Scaffold(
    //         appBar: AppBar(title: const Text('Scan Aadhaar QR')),
    //         body: MobileScanner(
    //           fit: BoxFit.contain,
    //           onDetect: (capture) {
    //             final List<Barcode> barcodes = capture.barcodes;
    //             if (barcodes.isNotEmpty) {
    //               final String? code = barcodes.first.rawValue;
    //               if (code != null) {
    //                 Navigator.pop(context, code); // return scanned result
    //               }
    //             }
    //           },
    //         ),
    //       );
    //     },
    //   ).then((result) async {
    //     if (result != null && result != '-1') {
    //       print('📌 Raw QR Result: $result');
    //
    //       if (result.toString().contains("PrintLetterBarcodeData")) {
    //         try {
    //           final document = xml.XmlDocument.parse(result);
    //           final element = document.rootElement;
    //
    //           final aadharDetails = {
    //             "uid": element.getAttribute("uid") ?? "",
    //             "name": element.getAttribute("name") ?? "",
    //             "gender": element.getAttribute("gender") ?? "",
    //             "yob": element.getAttribute("yob") ?? "",
    //             "co": element.getAttribute("co") ?? "",
    //             "loc": element.getAttribute("loc") ?? "",
    //             "vtc": element.getAttribute("vtc") ?? "",
    //             "po": element.getAttribute("po") ?? "",
    //             "dist": element.getAttribute("dist") ?? "",
    //             "state": element.getAttribute("state") ?? "",
    //             "pc": element.getAttribute("pc") ?? "",
    //           };
    //
    //           print("✅ Aadhaar Parsed: $aadharDetails");
    //
    //           // 🔑 Assign to controllers
    //           name.text = aadharDetails["name"] ?? "";
    //           aadhar.text = aadharDetails["uid"] ?? "";
    //
    //         } catch (e) {
    //           print("❌ XML Parse Error: $e");
    //         }
    //       }
    //     }
    //   });
    // } catch (e) {
    //   print('Failed to get barcode: $e');
    // }
  }

  // final document = xml.XmlDocument.parse(qrText!);
  // final element = document.rootElement;
  //
  // aadharDetails = {
  // "uid": element.getAttribute("uid") ?? "",
  // "name": element.getAttribute("name") ?? "",
  // "gender": element.getAttribute("gender") ?? "",
  // "yob": element.getAttribute("yob") ?? "",
  // "co": element.getAttribute("co") ?? "",
  // "house": element.getAttribute("house") ?? "",
  // "street": element.getAttribute("street") ?? "",
  // "loc": element.getAttribute("loc") ?? "",
  // "vtc": element.getAttribute("vtc") ?? "",
  // "po": element.getAttribute("po") ?? "",
  // "dist": element.getAttribute("dist") ?? "",
  // "state": element.getAttribute("state") ?? "",
  // "pc": element.getAttribute("pc") ?? "",
  // };
  // print(aadharDetails);
  //

//   Future<void> getAadhar() async {
//     final ImagePicker picker = ImagePicker();
//     final XFile? image = await picker.pickImage(source: ImageSource.camera);
//
//     if (image != null) {
//       // Convert picked image to InputImage
//       final inputImage = await cropQR(image.path);
//
//       final barcodeScanner = BarcodeScanner(formats: [BarcodeFormat.qrCode]);
//
//       // Process the image for QR codes
//       final barcodes = await barcodeScanner.processImage(inputImage);
//       if (barcodes.isEmpty) {
//         log("❌ No QR code detected in this image");
//       }else {
//         for (final barcode in barcodes) {
//           log("📌 Barcode Format: ${barcode.format}");
//           log("📌 Raw Value: ${barcode.rawValue}");
//           if (barcode.rawValue != null) {
//             log("📌 QR Raw Output: ${barcode.rawValue}");
//
//             setState(() {
//               qrText = barcode.rawValue; // Aadhaar QR text
//             });
//           }
//         }
//       }
//       // Close scanner after use
//       await barcodeScanner.close();
//
// // final textRecognizer = TextRecognizer();
//       // final RecognizedText recognisedText =
//       // await textRecognizer.processImage(inputImage);
//       //
//       // String fullText = recognisedText.text;
//       // debugPrint("📌 Extracted Text:\n$fullText");
//       //
//       // // --- Classification Logic ---
//       // String? aadharNumber;
//       // String? namedetect;
//       // String? address;
//       //
//       // for (TextBlock block in recognisedText.blocks) {
//       //   for (TextLine line in block.lines) {
//       //     String lineText = line.text.trim();
//       //
//       //     // Detect Aadhar Number (12 digits, sometimes grouped as XXXX XXXX XXXX)
//       //     if (RegExp(r'^\d{4}\s\d{4}\s\d{4}$').hasMatch(lineText)) {
//       //       aadharNumber = lineText;
//       //       aadhar.text = aadharNumber;
//       //     }
//       //     // Detect Name (Assume line before Aadhar number OR first capitalized line)
//       //     else if (aadharNumber == null &&
//       //         RegExp(r'^[A-Z][a-zA-Z\s]+$').hasMatch(lineText)) {
//       //       namedetect = lineText;
//       //       name.text = namedetect;
//       //     }
//       //     // Detect Address (keywords or multiple words after Aadhar or "Address" keyword)
//       //     else if (lineText.toLowerCase().contains("address") ||
//       //         (aadharNumber != null && name != null)) {
//       //       address = (address ?? "") + " " + lineText;
//       //     }
//       //   }
//       // }
//       //
//       // debugPrint("✅ Aadhar Number: $aadharNumber");
//       // debugPrint("✅ Name: $name");
//       // debugPrint("✅ Address: $address");
//       //
//       // await textRecognizer.close();
//     }
//   }

  // Future<void> getAadhar() async{
  //   final pickedFile = await ImagePicker().pickImage(source: ImageSource.camera);
  //   extractAadhaarDetails(pickedFile as File);
  //   // if(pickedFile != null ) {
  //   //   final textRecognizer = TextRecognizer();
  //   //   final inputImage = InputImage.fromFilePath(pickedFile.path);
  //   //   final RecognizedText recognizedText = await textRecognizer.processImage(
  //   //       inputImage);
  //   //
  //   //   String extractedText = recognizedText.text;
  //   //
  //   //
  //   //   final RegExp regex = RegExp(r'\b\d{4}\D*\d{4}\D*\d{4}\b');
  //   //   final match = regex.firstMatch(extractedText);
  //   //
  //   //   if (match != null) {
  //   //     // Remove spaces from Aadhaar number
  //   //     String aadhaarNumber = match.group(0)!.replaceAll(' ', '');
  //   //     aadhar.text = aadhaarNumber;
  //   //     print("Aadhaar Number: $aadhaarNumber");
  //   //   } else {
  //   //     print("No 16-digit sequence found");
  //   //   }
  //   //
  //   //   print(extractedText);
  //   // }
  // }

  @override
  void initState() {
    super.initState();
    cc.districtList(context);
    cc.collectionCenter(context);
    landdetails.add({
      "name": "",
      "community": "",
      "area": "",
      "quality": "",
      "district": "",
      "mandal": "",
      "state": "",
      "survey_no": "",
      "village": "",
      "location": "",
    });
  }

  bool isAadhaarValid = true; // declare in your state

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        iconTheme: const IconThemeData(
          color: Colors.white, // ✅ makes the back arrow white
        ),
        // automaticallyImplyLeading: false,
        title: Text(
          'Farmer Registration',
          style: CommonStyles.requestTextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 17),
        child: SingleChildScrollView(
          child: Obx(() => (isKisan.value)
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 0.0),
                      child: Row(
                        children: [
                          GestureDetector(
                            onTap: () => isKisan.value = true,
                            child: const Text(
                              "Farmer Details",
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.black,
                              ),
                            ),
                          ),
                          const Spacer(),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15.0, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                        // border: Border.all()
                      ),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            RichText(
                              text: const TextSpan(
                                text: "Name ",
                                style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                                children: [
                                  TextSpan(
                                      text: "*",
                                      style: TextStyle(
                                        color: Colors.red,
                                        fontSize: 13,
                                      ))
                                ],
                              ),
                            ),
                            CommonWidget(
                              child: TextField(
                                controller: name,
                                keyboardType: TextInputType.name,
                                // inputFormatters: [
                                //   FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z\s]')), // ✅ only letters and spaces
                                // ],
                                decoration: InputDecoration(
                                  hintText: 'Farmer Name',
                                  hintStyle: TextStyle(
                                      fontSize: 14, color: Colors.grey),
                                  border: InputBorder.none,
                                  contentPadding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 10),
                                ),
                              ),
                            ),
                            RichText(
                              text: const TextSpan(
                                text: "Aadhaar Number ",
                                style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                                children: [
                                  TextSpan(
                                      text: "*",
                                      style: TextStyle(
                                        color: Colors.red,
                                        fontSize: 13,
                                      ))
                                ],
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CommonWidget(
                                  width: width * 0.83,
                                  child: TextField(
                                    controller: aadhar,
                                    keyboardType: TextInputType.number,
                                    decoration: InputDecoration(
                                      hintText: 'Aadhaar Number',
                                      hintStyle: TextStyle(
                                          fontSize: 14, color: Colors.grey),
                                      border: InputBorder.none,
                                      contentPadding:
                                          const EdgeInsets.symmetric(
                                              horizontal: 10, vertical: 12),
                                      errorText: isAadhaarValid
                                          ? null
                                          : "Aadhaar number must be 12 digits",
                                      suffixIcon: Padding(
                                        padding: const EdgeInsets.only(
                                            right: 8.0, bottom: 4),
                                        child: GestureDetector(
                                          onTap: () async {
                                            _scanBin();
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                top: 5.0, left: 5),
                                            child: Container(
                                                decoration: BoxDecoration(
                                                  // border: Border.all(color: Colors.grey),
                                                  borderRadius:
                                                      BorderRadius.circular(12),
                                                  color: Colors.red[700],
                                                ),
                                                padding: EdgeInsets.all(5),
                                                child: Icon(
                                                  Icons.camera_alt,
                                                  color: Colors.white,
                                                )),
                                          ),
                                        ),
                                      ),
                                    ),
                                    onChanged: (val) {
                                      setState(() {
                                        isAadhaarValid = val.length == 12;
                                      });
                                    },
                                  ),
                                ),
                              ],
                            ),
                            RichText(
                              text: const TextSpan(
                                text: "Phone Number ",
                                style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                                children: [],
                              ),
                            ),
                            CommonWidget(
                              child: IntlPhoneField(
                                showDropdownIcon: false,
                                showCountryFlag: false,
                                disableLengthCheck: true, // we control it
                                flagsButtonPadding: const EdgeInsets.all(8),
                                dropdownIconPosition: IconPosition.trailing,
                                initialCountryCode: 'IN',
                                keyboardType: TextInputType.number,
                                inputFormatters: <TextInputFormatter>[
                                  FilteringTextInputFormatter
                                      .digitsOnly, // only numbers
                                  LengthLimitingTextInputFormatter(
                                      10), // max 10 digits
                                ],
                                decoration: InputDecoration(
                                  counterText: "", // hides the length counter
                                  contentPadding: const EdgeInsets.symmetric(
                                      vertical: 12, horizontal: 12),
                                  hintText: 'Enter Mobile Number',
                                  hintStyle: TextStyle(
                                    fontWeight: FontWeight.normal,
                                    fontSize: 14,
                                    color: Colors.grey.shade400,
                                  ),
                                  border: OutlineInputBorder(
                                    borderSide: BorderSide.none,
                                  ),
                                ),
                                onChanged: (phone) {
                                  phoneController.text = phone.number;
                                },
                              ),
                            ),

                            // Container(
                            //   margin: const EdgeInsets.all(6),
                            //   padding: const EdgeInsets.only(
                            //       top: 12),
                            //   decoration: BoxDecoration(
                            //     color: Colors.grey.shade50,
                            //     borderRadius:
                            //     BorderRadius.circular(15),
                            //   ),
                            //   child:

                            CommonWidget(
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Obx(() {
                                      return address.isNotEmpty
                                          ? Container(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 7.0),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  const SizedBox(height: 5),
                                                  Text(
                                                    address.toString(),
                                                    style: const TextStyle(
                                                      fontSize: 13,
                                                      color: Colors.black,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                    ),
                                                  ),
                                                  Row(
                                                    children: [
                                                      GestureDetector(
                                                        onTap: () async {
                                                          final updatedAddress =
                                                              await showModalBottomSheet<
                                                                  Map<String,
                                                                      dynamic>>(
                                                            isScrollControlled:
                                                                true,
                                                            context: context,
                                                            builder: (context) =>
                                                                SingleChildScrollView(
                                                              child: Padding(
                                                                padding:
                                                                    EdgeInsets
                                                                        .only(
                                                                  bottom: MediaQuery.of(
                                                                          context)
                                                                      .viewInsets
                                                                      .bottom,
                                                                ),
                                                                child:
                                                                    AddAddressWidget(
                                                                  district:
                                                                      selectedDistrict,
                                                                  mandal:
                                                                      selectedMandal,
                                                                  village:
                                                                      selectedVillage,
                                                                ),
                                                              ),
                                                            ),
                                                          );

                                                          if (updatedAddress !=
                                                              null) {
                                                            setState(() {
                                                              // 🟢 Update address values
                                                              address.value = [
                                                                updatedAddress[
                                                                    "village"],
                                                                updatedAddress[
                                                                    "mandal"],
                                                                updatedAddress[
                                                                    "district"]
                                                              ];

                                                              selectedDistrict =
                                                                  updatedAddress[
                                                                      "district"];
                                                              selectedMandal =
                                                                  updatedAddress[
                                                                      "mandal"];
                                                              selectedVillage =
                                                                  updatedAddress[
                                                                      "village"];

                                                              // 🟢 Update landdetails for current entry (e.g., index = 0 or dynamic)
                                                              landdetails[0][
                                                                      "location"] =
                                                                  "${selectedVillage}, ${selectedMandal}, ${selectedDistrict}";
                                                              landdetails[0][
                                                                      "district"] =
                                                                  selectedDistrict;
                                                              landdetails[0][
                                                                      "mandal"] =
                                                                  selectedMandal;
                                                              landdetails[0][
                                                                      "village"] =
                                                                  selectedVillage;
                                                            });
                                                          }
                                                        },
                                                        child: const Text(
                                                          'Edit',
                                                          style: TextStyle(
                                                            color:
                                                                Color.fromARGB(
                                                                    255,
                                                                    6,
                                                                    138,
                                                                    246),
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontSize: 13,
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  )
                                                ],
                                              ),
                                            )
                                          : GestureDetector(
                                              //?./
                                              onTap: () async {
                                                final newAddress =
                                                    await showModalBottomSheet<
                                                        Map<String, dynamic>>(
                                                  isScrollControlled: true,
                                                  context: context,
                                                  builder: (context) =>
                                                      SingleChildScrollView(
                                                    child: Padding(
                                                      padding: EdgeInsets.only(
                                                        bottom: MediaQuery.of(
                                                                context)
                                                            .viewInsets
                                                            .bottom,
                                                      ),
                                                      child: AddAddressWidget(
                                                        district:
                                                            selectedDistrict,
                                                        mandal: selectedMandal,
                                                        village:
                                                            selectedVillage,
                                                      ),
                                                    ),
                                                  ),
                                                );

                                                if (newAddress != null) {
                                                  print(newAddress);
                                                  setState(() {
                                                    address.value = [
                                                      newAddress["village"],
                                                      newAddress["mandal"],
                                                      newAddress["district"]
                                                    ];
                                                    selectedDistrict =
                                                        newAddress["district"];
                                                    selectedMandal =
                                                        newAddress["mandal"];
                                                    selectedVillage =
                                                        newAddress["village"];

                                                    landdetails[0]["location"] =
                                                        "${selectedVillage}, ${selectedMandal}, ${selectedDistrict}";
                                                    // landdetails[0]["location"] = address.value;
                                                    landdetails[0]["district"] =
                                                        selectedDistrict;
                                                    landdetails[0]["mandal"] =
                                                        selectedMandal;
                                                    landdetails[0]["village"] =
                                                        selectedVillage;

                                                    for (var i = 1;
                                                        i < landdetails.length;
                                                        i++) {
                                                      if ((landdetails[i][
                                                                  "location"] ??
                                                              "")
                                                          .isEmpty) {
                                                        landdetails[i]
                                                                ["location"] =
                                                            "${selectedVillage}, ${selectedMandal}, ${selectedDistrict}";
                                                        landdetails[i]
                                                                ["district"] =
                                                            selectedDistrict;
                                                        landdetails[i]
                                                                ["mandal"] =
                                                            selectedMandal;
                                                        landdetails[i]
                                                                ["village"] =
                                                            selectedVillage;
                                                      }
                                                    }
                                                  });
                                                }
                                                ;
                                              },
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.all(4.0),
                                                child: Row(
                                                  children: [
                                                    Icon(Icons.add_circle,
                                                        color: Colors
                                                            .grey.shade600,
                                                        size: 17),
                                                    Text(
                                                      " Address",
                                                      style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        color: Colors
                                                            .grey.shade600,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            );
                                    }),
                                  ],
                                ),
                              ),
                            ),
                            CommonWidget(child: Obx(() {
                              if (cc.isLoading11.value) {
                                return Center(
                                    child: CircularProgressIndicator());
                              }

                              final items = cc.collectionList.isNotEmpty
                                  ? cc.collectionList
                                      .map((village) =>
                                          DropdownMenuItem<String>(
                                            value: village['collection_centre'],
                                            child: Text(village['collection_centre']),
                                          ))
                                      .toList()
                                  : [
                                      DropdownMenuItem<String>(
                                        value: "0", // dummy value
                                        child: Text(
                                          "No Collection Center",
                                          style: TextStyle(
                                            fontWeight: FontWeight.normal,
                                            fontSize: 11,
                                            color: Colors.grey.shade400,
                                          ),
                                        ),
                                      )
                                    ];

                              return DropdownButtonFormField<String>(
                                initialValue: selectedCenter,
                                items: items,
                                onChanged: (val) {
                                  setState(() {
                                    selectedCenter = val!;
                                  });
                                },
                                decoration: InputDecoration(
                                  hintText: 'Collection Center',
                                  contentPadding: const EdgeInsets.symmetric(
                                      vertical: 12, horizontal: 12),
                                  hintStyle: TextStyle(
                                    fontWeight: FontWeight.normal,
                                    fontSize: 14,
                                    color: Colors.grey.shade400,
                                  ),
                                  border: OutlineInputBorder(
                                    borderSide: BorderSide.none,
                                  ),
                                ),
                              );
                            })),
                          ]),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 0.0),
                      child: Row(
                        children: [
                          GestureDetector(
                            onTap: () => isKisan.value = true,
                            child: const Text(
                              "Bank Details",
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                                color: Colors.black,
                              ),
                            ),
                          ),
                          const Spacer(),
                        ],
                      ),
                    ),
                    Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 15.0, vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(15),
                          // border: Border.all()
                        ),
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RichText(
                                text: const TextSpan(
                                  text: "Bank Account No ",
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: [
                                    TextSpan(
                                        text: "*",
                                        style: TextStyle(
                                          color: Colors.red,
                                          fontSize: 13,
                                        ))
                                  ],
                                ),
                              ),
                              CommonWidget(
                                child: TextField(
                                  controller: accountNumber,
                                  keyboardType: TextInputType.number,
                                  decoration: InputDecoration(
                                    hintText: 'Account Number',
                                    border: InputBorder.none,
                                    contentPadding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 10),
                                    suffixIcon: Container(
                                      width: 100,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        borderRadius: const BorderRadius.only(
                                          topRight: Radius.circular(5),
                                          bottomRight: Radius.circular(5),
                                        ),
                                        color: AppColors.primary,
                                      ),
                                      child: const Text(
                                        "Fetch Details",
                                        style: TextStyle(
                                          fontSize: 13,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              RichText(
                                text: const TextSpan(
                                  text: "Bank Name ",
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: [],
                                ),
                              ),
                              CommonWidget(
                                child: TextField(
                                  controller: bankName,
                                  keyboardType: TextInputType.text,
                                  decoration: InputDecoration(
                                    hintText: 'Bank Name',
                                    border: InputBorder.none,
                                    contentPadding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 10),
                                  ),
                                ),
                              ),
                              RichText(
                                text: const TextSpan(
                                  text: "IFSC Code ",
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  children: [],
                                ),
                              ),
                              CommonWidget(
                                child: TextField(
                                  controller: ifsc,
                                  keyboardType: TextInputType.text,
                                  decoration: InputDecoration(
                                    hintText: 'IFSC Code',
                                    border: InputBorder.none,
                                    contentPadding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 10),
                                  ),
                                ),
                              ),
                            ])),

                    RichText(
                      text: const TextSpan(
                        text: "Land Details ",
                        style: TextStyle(
                          fontSize: 13,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                        children: [],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15.0, vertical: 12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                        // border: Border.all()
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ListView.builder(
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              itemCount: landdetails.length,
                              itemBuilder: (context, index) {
                                return Column(
                                  children: [
                                    Row(
                                      children: [
                                        CommonWidget(
                                          width: width * 0.65,
                                          child: TextFormField(
                                            initialValue: landdetails[index]
                                                    ["survey_no"] ??
                                                "",
                                            decoration: InputDecoration(
                                              hintText: 'Land Survey No',
                                              border: InputBorder.none,
                                              contentPadding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 10,
                                                      vertical: 10),
                                            ),
                                            onChanged: (val) {
                                              landdetails[index]["survey_no"] =
                                                  val;
                                            },
                                          ),
                                        ),
                                        (index == 0)
                                            ? GestureDetector(
                                                onTap: () {
                                                  setState(() {
                                                    landdetails.add({
                                                      "name": "",
                                                      "community": '',
                                                      "area": "",
                                                      "quality": "",
                                                      "district":"",
                                                      "mandal": selectedMandal,
                                                      "state": "",
                                                      "survey_no": "",
                                                      "village":
                                                          selectedVillage,
                                                      "location":
                                                          "${selectedVillage}, ${selectedMandal}, ${selectedDistrict}",
                                                    });
                                                  });
                                                },
                                                child: Container(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            left: 22),
                                                    child: const Text(
                                                      'ADD',
                                                      style: TextStyle(
                                                        fontSize: 15,
                                                        color: Colors
                                                            .blue, // Blue color for the plus sign
                                                        fontWeight:
                                                            FontWeight.bold,
                                                      ),
                                                    )),
                                              )
                                            : GestureDetector(
                                                onTap: () {
                                                  setState(() {
                                                    landdetails.removeAt(index);
                                                  });
                                                },
                                                child: Container(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 22),
                                                  child: const Text(
                                                    '❌',
                                                    style: TextStyle(
                                                        fontSize: 15,
                                                        color: Colors.blue,
                                                        fontWeight:
                                                            FontWeight.w500),
                                                  ),
                                                ),
                                              )
                                      ],
                                    ),
                                    // CommonWidget(
                                    //   child: Obx(() {
                                    //     if (cc.isLoading8.value) {
                                    //       return const Center(
                                    //           child:
                                    //               CircularProgressIndicator());
                                    //     }
                                    //
                                    //     return DropdownButtonFormField<
                                    //         String>(
                                    //       value: landdetails[index]
                                    //                   ["community"]
                                    //               .toString()
                                    //               .isNotEmpty
                                    //           ? landdetails[index]
                                    //               ["community"]
                                    //           : null, // start with null
                                    //       items: cc.varietyData
                                    //           .map((district) =>
                                    //               DropdownMenuItem<
                                    //                   String>(
                                    //                 value: district[
                                    //                         'variety']
                                    //                     .toString(),
                                    //                 child: Text(
                                    //                     district[
                                    //                         'variety']),
                                    //               ))
                                    //           .toList(),
                                    //       onChanged: (val) {
                                    //         setState(() {
                                    //           landdetails[index]
                                    //                   ["community"] =
                                    //               val ?? "";
                                    //         });
                                    //       },
                                    //       decoration:
                                    //           const InputDecoration(
                                    //         hintText: 'Variety',
                                    //         border: InputBorder.none,
                                    //         contentPadding:
                                    //             EdgeInsets.symmetric(
                                    //                 horizontal: 10,
                                    //                 vertical: 0),
                                    //       ),
                                    //     );
                                    //   }),
                                    // ),
                                    Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              CommonWidget(
                                                width: width * 0.5,
                                                child: TextFormField(
                                                  keyboardType:
                                                      TextInputType.number,
                                                  initialValue:
                                                      landdetails[index]
                                                              ["acre"] ??
                                                          "",
                                                  decoration: InputDecoration(
                                                    hintText: 'Acre',
                                                    border: InputBorder.none,
                                                    contentPadding:
                                                        const EdgeInsets
                                                            .symmetric(
                                                            horizontal: 10,
                                                            vertical: 10),
                                                  ),
                                                  onChanged: (val) {
                                                    landdetails[index]["acre"] =
                                                        val;
                                                  },
                                                ),
                                              ),
                                              Padding(
                                                padding:
                                                    EdgeInsets.only(left: 10),
                                                child: Text(
                                                  'acres',
                                                  style: TextStyle(
                                                      fontSize: 16,
                                                      fontWeight:
                                                          FontWeight.w500),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ]),
                                    Container(
                                      margin: const EdgeInsets.all(0),
                                      padding: const EdgeInsets.only(top: 5),
                                      decoration: BoxDecoration(
                                        color: Colors.grey.shade50,
                                        borderRadius: BorderRadius.circular(15),
                                      ),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Obx(() {
                                            final String billingAddress =
                                                landdetails[index]
                                                        ["location"] ??
                                                    "";

                                            return billingAddress.isNotEmpty
                                                ? Container(
                                                    padding: const EdgeInsets
                                                        .symmetric(
                                                        horizontal: 7.0),
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text(
                                                          "Land Location",
                                                          style: TextStyle(
                                                            fontSize: 10,
                                                            color: Colors
                                                                .grey.shade600,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                        const SizedBox(
                                                            height: 5),
                                                        Text(
                                                          billingAddress,
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 13,
                                                            color: Colors.black,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                          ),
                                                        ),
                                                        Row(
                                                          children: [
                                                            GestureDetector(
                                                              onTap: () async {
                                                                final updatedAddress =
                                                                    await showModalBottomSheet<
                                                                        Map<String,
                                                                            dynamic>>(
                                                                  isScrollControlled:
                                                                      true,
                                                                  context:
                                                                      context,
                                                                  builder:
                                                                      (context) =>
                                                                          SingleChildScrollView(
                                                                    child:
                                                                        Padding(
                                                                      padding:
                                                                          EdgeInsets
                                                                              .only(
                                                                        bottom: MediaQuery.of(context)
                                                                            .viewInsets
                                                                            .bottom,
                                                                      ),
                                                                      child: AddAddressWidget(
                                                                          // district: landdetails[index]["district"] ,
                                                                          // mandal: landdetails[index]["mandal"] ,
                                                                          // village: landdetails[index]["village"] ,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                );

                                                                if (updatedAddress !=
                                                                    null) {
                                                                  setState(() {
                                                                    landdetails[index]
                                                                            [
                                                                            "location"] =
                                                                        "${updatedAddress["village"]},${updatedAddress["mandal"]},${updatedAddress["district"]}";

                                                                    landdetails[index]
                                                                            [
                                                                            "district"] =
                                                                        updatedAddress[
                                                                            "district"];
                                                                    landdetails[index]
                                                                            [
                                                                            "mandal"] =
                                                                        updatedAddress[
                                                                            "mandal"];

                                                                    landdetails[index]
                                                                            [
                                                                            "village"] =
                                                                        updatedAddress[
                                                                            "village"];
                                                                  });
                                                                }
                                                              },
                                                              child: const Text(
                                                                'Edit',
                                                                style:
                                                                    TextStyle(
                                                                  color: Color
                                                                      .fromARGB(
                                                                          255,
                                                                          6,
                                                                          138,
                                                                          246),
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  fontSize: 13,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        )
                                                      ],
                                                    ),
                                                  )
                                                : GestureDetector(
                                                    onTap: () async {
                                                      final newAddress =
                                                          await showModalBottomSheet<
                                                              Map<String,
                                                                  dynamic>>(
                                                        isScrollControlled:
                                                            true,
                                                        context: context,
                                                        builder: (context) =>
                                                            SingleChildScrollView(
                                                          child: Padding(
                                                            padding:
                                                                EdgeInsets.only(
                                                              bottom: MediaQuery
                                                                      .of(context)
                                                                  .viewInsets
                                                                  .bottom,
                                                            ),
                                                            child: AddAddressWidget(
                                                                district:
                                                                    selectedDistrict,
                                                                mandal:
                                                                    selectedMandal),
                                                          ),
                                                        ),
                                                      );

                                                      if (newAddress != null) {
                                                        print(newAddress);
                                                        setState(() {
                                                          landdetails[index]
                                                                  ["location"] =
                                                              "${newAddress["village"]},${newAddress["mandal"]},${newAddress["district"]}";
                                                          landdetails[index]
                                                                  ["district"] =
                                                              newAddress[
                                                                  "district"];
                                                          landdetails[index]
                                                                  ["mandal"] =
                                                              newAddress[
                                                                  "mandal"];
                                                          landdetails[index]
                                                                  ["village"] =
                                                              newAddress[
                                                                  "village"];
                                                        });
                                                      }
                                                      ;
                                                    },
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.all(
                                                              4.0),
                                                      child: Row(
                                                        children: [
                                                          Icon(Icons.add_circle,
                                                              color: Colors.grey
                                                                  .shade600,
                                                              size: 17),
                                                          Text(
                                                            " Land Address / Location",
                                                            style: TextStyle(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                              color: Colors.grey
                                                                  .shade600,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  );
                                          })
                                        ],
                                      ),
                                    ),
                                    if (index != landdetails.length - 1)
                                      // Padding(
                                      //   padding:
                                      //       const EdgeInsets.only(top: 12.0),
                                      //   child:
                                      const Divider(
                                        color: Colors.grey,
                                        //   ),
                                      ),
                                  ],
                                );
                              }),
                          // Row(
                          //   mainAxisAlignment:
                          //   MainAxisAlignment.spaceBetween,
                          //   children: [
                          //     Padding(
                          //       padding: const EdgeInsets.symmetric(
                          //           vertical: 15.0),
                          //       child: ButtonBS(
                          //         onPressed: () {
                          //           isKisan.value = true;
                          //           landdetails.clear();
                          //         },
                          //         title: 'Previous',
                          //         textColor: Colors.white,
                          //         fontSize: 12,
                          //         fontWeight: FontWeight.w600,
                          //         width: width * 0.3,
                          //         height: height * 0.04,
                          //         // width: width * 0.39,
                          //         // height: height * 0.04,
                          //         padding: 0.0,
                          //         backgroundColor: AppColors.primary,
                          //         borderRadius: 15,
                          //         // child: Text('Submit Request',style: TextStyle(color: Colors.red),),
                          //       ),
                          //     ),
                          //     Padding(
                          //       padding: const EdgeInsets.symmetric(
                          //           vertical: 15.0),
                          //       child: ButtonBS(
                          //         onPressed: () {
                          //           isLand.value = false;
                          //         },
                          //         title: 'Next ➤',
                          //         textColor: Colors.white,
                          //         fontSize: 12,
                          //         fontWeight: FontWeight.w600,
                          //         width: width * 0.3,
                          //         height: height * 0.04,
                          //         // width: width * 0.39,
                          //         // height: height * 0.04,
                          //         padding: 5.0,
                          //         backgroundColor: AppColors.primary,
                          //         borderRadius: 15,
                          //         // child: Text('Submit Request',style: TextStyle(color: Colors.red),),
                          //       ),
                          //     ),
                          //   ],
                          // )
                        ],
                      ),

                      // CommonWidget(
                      //   child: TextFormField(
                      //     controller: state,
                      //     decoration: InputDecoration(
                      //       // hintText: 'Comments',
                      //       hintText: 'State',
                      //       border: InputBorder.none,
                      //       contentPadding: const EdgeInsets.symmetric(
                      //           horizontal: 10, vertical: 10),
                      //     ),
                      //     validator: (value) => value!.isEmpty
                      //         ? 'Please select State'
                      //         : null,
                      //     minLines: 1,
                      //     maxLines:
                      //     5, // expands up to 5 lines as user types
                      //     keyboardType: TextInputType.multiline,
                      //   ),
                      // ),

                      // CommonWidget(
                      //   child: TextFormField(
                      //     controller: address,
                      //     decoration: InputDecoration(
                      //       // hintText: 'Comments',
                      //       hintText: 'Address',
                      //       border: InputBorder.none,
                      //       contentPadding: const EdgeInsets.symmetric(
                      //           horizontal: 10, vertical: 10),
                      //     ),
                      //     validator: (value) => value!.isEmpty
                      //         ? 'Please enter Address'
                      //         : null,
                      //     minLines: 1,
                      //     maxLines:
                      //     5, // expands up to 5 lines as user types
                      //     keyboardType: TextInputType.multiline,
                      //   ),
                      // ),fe

                      // Padding(
                      //   padding: const EdgeInsets.only(top: 23.0),
                      //   child: Column(
                      //     crossAxisAlignment: CrossAxisAlignment.start,
                      //     children: [
                      //       Row(
                      //         children: [
                      //           Checkbox(
                      //             value: isChecked,
                      //             onChanged: (val) {
                      //               setState(() {
                      //                 isChecked = val ?? false;
                      //               });
                      //             },
                      //           ),
                      //           Text(
                      //             'Passbook',
                      //             style:
                      //                 CommonStyles.requestTextStyle(),
                      //           ),
                      //         ],
                      //       ),
                      //       if (isChecked) // ✅ Show only when checked
                      //         CommonWidget(
                      //           child: TextField(
                      //             controller: passbookController,
                      //             keyboardType: TextInputType.number,
                      //             decoration: InputDecoration(
                      //               contentPadding:
                      //                   EdgeInsets.symmetric(
                      //                       vertical: 12,
                      //                       horizontal: 12),
                      //               hintText: 'Enter Passbook Number',
                      //               hintStyle: TextStyle(
                      //                   fontWeight: FontWeight.normal,
                      //                   fontSize: 16,
                      //                   color: Colors.grey.shade400),
                      //               border: OutlineInputBorder(
                      //                 borderSide: BorderSide.none,
                      //               ),
                      //             ),
                      //           ),
                      //         ),
                      //     ],
                      //   ),
                      // ),
                    ),

                    // Checkbox(
                    //   shape: RoundedRectangleBorder(
                    //     borderRadius: BorderRadius.circular(9), // Change to 20 for more rounded corners
                    //   ),
                    //   value: isGroup,
                    //   onChanged: (val) =>
                    //       setState(() => isGroup = val!),
                    // ),
                    //  Text('Group Travel?',style: TextStyle(fontSize: width * 0.03),)
                    // ],
                    // SwitchListTile(
                    //   title: Text('Is Group Travel?'),
                    //   value: isGroup,
                    //   onChanged: (val) => setState(() => isGroup = val),
                    // ),

                    // SizedBox(
                    //   height: height * 0.025,
                    // ),
                  ],
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Preview",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8),

                    Container(
                      width: width * 1,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.white),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          children: [
                            buildPreviewRow("Farmer Name", name.text),
                            buildPreviewRow("Aadhaar", aadhar.text),
                            buildPreviewRow("Mobile", phoneController.text),
                            buildPreviewRow("Bank name", bankName.text),
                            buildPreviewRow("Account No", accountNumber.text),
                            buildPreviewRow("IFSC Code", ifsc.text),
                            buildPreviewRow("District", selectedDistrict ?? ""),
                            buildPreviewRow("Mandal", selectedMandal ?? ""),
                            buildPreviewRow("Village", selectedVillage ?? ""),
                            buildPreviewRow(
                                "Collection Center", selectedCenter ?? ""),

                            // buildPreviewRow("Village",
                            //     isChecked ? "Yes" : "No"),
                            // if (isChecked &&
                            //     passbookController
                            //         .text.isNotEmpty)
                            //   buildPreviewRow("Passbook Number",
                            //       passbookController.text),
                          ],
                        ),
                      ),
                    ),

                    SizedBox(height: 10),

                    // 🔹 Loop through each land detail
                    ListView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: landdetails.length,
                      itemBuilder: (context, index) {
                        final landItem = landdetails[index];

                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Land ${index + 1}",
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            buildPreviewRow(
                                "Survey No", landItem["survey_no"] ?? ""),
                            // buildPreviewRow("Land Variety",
                            //     landItem["community"] ?? ""),
                            buildPreviewRow(
                                "Land Acres", landItem["acre"] ?? ""),
                            // buildPreviewRow("Quality Grade", landItem["quality"] ?? ""),
                            buildPreviewRow(
                                "Location", landItem["location"] ?? ""),

                            if (index != landdetails.length - 1)
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 8.0),
                                child: Divider(color: Colors.red),
                              ),
                          ],
                        );
                      },
                    ),
                  ],
                )),
        ),
      ),
      bottomNavigationBar: Container(
        height: 60,
        decoration: const BoxDecoration(color: Colors.white),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 0),
          child: Obx(
            () => isKisan.value
                ? Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          (errorValue.value)
                              ? SizedBox(
                                  width: width * 0.5,
                                  child: Text(
                                    errorMsg,
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 5,
                                    style: TextStyle(color: Colors.red),
                                  ),
                                )
                              : Text(''),
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 5.0),
                            child: ButtonBS(
                              onPressed: () {
                                if (name.text.isEmpty ||
                                    phoneController.text.isEmpty ||
                                    aadhar.text.isEmpty ||
                                    selectedDistrict == null ||
                                    selectedMandal == null ||selectedCenter == null ||
                                    isChecked) {
                                  errorValue.value = true;
                                  errorMsg =
                                      "Please fill all the \n required fields";
                                  return;
                                }
                                if (accountNumber.text.isEmpty ||
                                    bankName.text.isEmpty ||
                                    ifsc.text.isEmpty) {
                                  errorValue.value = true;
                                  errorMsg = "Please fill bank details";
                                  return;
                                }

                                isKisan.value = false;
                                isLand.value = false;
                              },
                              title: 'Proceed ➤',
                              textColor: Colors.red,
                              fontSize: 17,
                              fontWeight: FontWeight.w600,
                              // width: width * 0.34,
                              // height: height * 0.03,
                              // width: width * 0.39,
                              // height: height * 0.04,
                              padding: 5.0,
                              backgroundColor: AppColors.white,
                              borderRadius: 15,
                              // child: Text('Submit Request',style: TextStyle(color: Colors.red),),
                            ),
                          ),
                        ],
                      ),
                    ],
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 0.0),
                        child: ButtonBS(
                          onPressed: () {
                            isKisan.value = true;
                            errorValue.value = false;
                          },
                          title: 'Previous',
                          textColor: Colors.red,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          width: width * 0.3,
                          height: height * 0.04,
                          padding: 0.0,
                          backgroundColor: AppColors.container,
                          borderRadius: 15,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 0.0),
                        child: ButtonBS(
                          onPressed: () {
                            registerFarmer();
                          },
                          title: 'Register',
                          textColor: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          width: width * 0.3,
                          height: height * 0.04,
                          padding: 0.0,
                          backgroundColor: AppColors.primary,
                          borderRadius: 8,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  Widget buildPreviewRow(String? label, String? value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 140, // fixed width for labels so colons align
            child: Text(
              "$label :",
              style: TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
          Expanded(
            child: Text(value ?? ""),
          ),
        ],
      ),
    );
  }
}

class FromToController {
  final TextEditingController from;
  final TextEditingController to;

  FromToController({required this.from, required this.to});
}
