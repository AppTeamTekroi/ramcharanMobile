import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ramcharan/Login/login_controller.dart';

import '../Login/loginScreen.dart';
import '../ui/Buttons/button.dart';
import '../ui/CommonBackground.dart';
import '../ui/assets/app_assets.dart';
import '../ui/color/appColor.dart';
import '../ui/headers.dart';
import '../ui/widgets/CommonWidget.dart';
import 'package:get/get.dart';


class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {

  final Map<String, String> dummyProfile = {
    'Name': 'Krishna Prakash',
    'Phone': '+91 98765 43210',
    'Email': 'krishna@example.com',
    'Hospital': 'Apollo Hospitals',
    'Branch': 'Hyderabad',
    'Address': '5th Floor, Tech Park, Gachibowli',
    'City': 'Hyderabad',
  };

LoginController lc = Get.put(LoginController());
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery
        .of(context)
        .size
        .height;
    final w = MediaQuery
        .of(context)
        .size
        .width;

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: Stack(children: [
        Container(
          width: w,
          height: h/4,

          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(AppImagePaths.background),
              fit: BoxFit.cover, // You can change to BoxFit.fill if needed
            ),
          ),
        ),

        SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 16.0, top: h*0.08),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 26,
                          backgroundColor: Colors.white.withOpacity(0.2),
                          child: Icon(Icons.person, size: 28, color: Colors.white),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          "Profile",
                          style: GoogleFonts.roboto(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            showModalBottomSheet(
                              isScrollControlled: true,
                              context: context,
                              backgroundColor: Colors.transparent,
                              builder: (context) => Padding(
                                padding: EdgeInsets.only(
                                    bottom: MediaQuery.of(context).viewInsets.bottom),
                                child: ProfileWidget(),
                              ),
                            );
                          },
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(Icons.edit, color: Colors.white, size: 22),
                          ),
                        ),
                        GestureDetector(

              onTap: () async{

              bool shouldLogout = await showDialog(
              context: context,
              builder: (BuildContext context) {
              return AlertDialog(
              shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5.0),
              ),
              backgroundColor: Colors.white,
              content: const Text(
              "Are you sure you want to logout?",
              style: TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.bold,
              ),
              ),
              actions: <Widget>[
              TextButton(
              child:  Text(
              "Yes",
              style: TextStyle(
              color: AppColors.primary,
              fontWeight: FontWeight.bold,
              ),
              ),
              onPressed: () async {
              await lc.logOutUser();
              final SharedPreferences _prefs =
              await SharedPreferences.getInstance();
              _prefs.setString('token', '');

              String? access_token =
              _prefs.getString('access_token');
              print(
              'Access Token after clearing: $access_token');
              Get.offAll(() => const LoginScreen());
              },
              ),
              TextButton(
              child:  Text(
              "No",
              style: TextStyle(
              color: AppColors.primary,
              fontWeight: FontWeight.bold,
              ),
              ),
              onPressed: () {
              Navigator.of(context).pop(false);
              },
              ),
              ],
              );
              },
              );

              if (shouldLogout == true) {
              lc.logOutUser();
              }
              },


                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(Icons.logout, color: Colors.white, size: 22),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                  decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white24, width: 1),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Name',
                          style: GoogleFonts.roboto(
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                              color: Colors.white)),
                      const SizedBox(height: 4),
                      Text(dummyProfile['Name'] ?? "N/A",
                          style: GoogleFonts.roboto(
                              fontSize: 15,
                              color: Colors.white,
                              fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
              ),
              // ✅ Dummy profile rows
              _profileRow("Phone", dummyProfile['Phone']),
              _profileRow("Email", dummyProfile['Email']),

              _profileRow("City", dummyProfile['City']),

              const SizedBox(height: 10),

              Padding(
                padding: const EdgeInsets.only(right: 15.0),
                child: Align(
                  alignment: Alignment.bottomRight,
                  child: Image(
                    height: h * 0.03, // Adjust the height of the image
                    image: AssetImage(AppImagePaths.tekroilogo),
                  ),
                ),
              ),
              const SizedBox(height: 10),
            ],
          ),
        ),
      ]
      ),


    );
  }


  Widget _profileRow(String label, String? value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16),
      child: Container(
        width: MediaQuery.of(context).size.width,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          color: Colors.white30.withOpacity(0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.grey, width: 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label,
                style: GoogleFonts.roboto(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: Colors.black)),
            const SizedBox(height: 4),
            Text(value ?? "N/A",
                style: GoogleFonts.roboto(
                    fontSize: 15,
                    color: Colors.red,
                    fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }

}


class ProfileWidget extends StatefulWidget {

  const ProfileWidget({super.key, });

  @override
  State<ProfileWidget> createState() => _AddAddressWidgetState();
}

class _AddAddressWidgetState extends State<ProfileWidget> {

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();



  @override
  Widget build(BuildContext context) {
    final width = MediaQuery
        .of(context)
        .size
        .width;
    final height = MediaQuery
        .of(context)
        .size
        .height;
    return Container(
      width: width,
      height: height * 0.45,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(22),
          topRight: Radius.circular(22),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 10),
              Center(
                child: Container(
                  height: 3,
                  width: 80,
                  decoration: BoxDecoration(
                    color: Colors.grey,
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),



              Padding(
                padding: const EdgeInsets.symmetric(vertical: 11.0),
                child: Center(

                  child: Text(
                    "Edit/Update Profile",
                    style: GoogleFonts.roboto(
                      fontSize: 17,
                      color: Colors.black,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),

              SizedBox(height: height*0.015),

              Container(
                width: width,
                height:  height *0.055,
                padding: EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(25),
                ),
                child: TextField(
                  controller: _nameController,
                  style: TextStyle(
                    fontSize: height * 0.02,
                    color: Colors.black,
                  ),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: 'name',
                    hintStyle: TextStyle(
                      color: AppColors.container,

                      fontSize:
                      Get.height * 0.018,
                      fontWeight: FontWeight.w500,
                    ),
                    //  padding: EdgeInsets.all(12),
                  ),

                ),
              ),
              SizedBox(height: height*0.015),

              Container(
                width: width,
                height:  height *0.055,
                padding: EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(25),
                ),
                child: TextField(
                  controller: _emailController,
                  style: TextStyle(
                    fontSize: height * 0.02,
                    color: Colors.black,
                  ),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: 'email',
                    hintStyle: TextStyle(
                      color: AppColors.container,

                      fontSize:
                      Get.height * 0.018,
                      fontWeight: FontWeight.w500,
                    ),
                    //  padding: EdgeInsets.all(12),
                  ),

                ),
              ),
              SizedBox(height: height*0.015),

              Container(
                // height: height * 0.06,
                //  width: width * 0.85,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30),
                  border:
                  Border.all(color: Colors.grey),
                ),
                child: IntlPhoneField(
                  onCountryChanged: (val) {
                    // cc.dial_code.value = val.dialCode;
                  },
                  showDropdownIcon: false,
                  showCountryFlag: false, // Hides the country code

                  disableLengthCheck: true,
                  flagsButtonPadding: const EdgeInsets.all(8),
                  dropdownIconPosition: IconPosition.trailing,
                  decoration: InputDecoration(
                    // contentPadding:
                    // const EdgeInsets.only(left: 12, top: 7),
                    contentPadding: EdgeInsets.symmetric(
                        vertical: 12, horizontal: 12),

                    hintText: ' Mobile Number',
                    hintStyle: TextStyle(
                        fontWeight: FontWeight.normal,
                        fontSize: 16,
                        color: Colors.grey.shade400),
                    border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                    ),
                  ),
                  initialCountryCode: 'IN',
                  onChanged: (phone) {
                    //  loginController.UserName.value = phone.number; // Get full number

                  },
                ),
              ),



              SizedBox(height: height*0.015),
              //  (isNotToday != true) ?
              Container(
                height: 90,
                decoration: const BoxDecoration(
                  color: Colors.white,
                ),

                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 0.0),
                    child: ButtonBS(
                      title: 'Submit',
                      textColor: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      width: width * 0.8,
                      height: height * 0.055,
                      // width: width * 0.39,
                      // height: height * 0.04,
                      padding: 5.0,
                      backgroundColor: AppColors.primary,
                      borderRadius: 25,
                      // suffixIcon: Icons.arrow_forward_ios,
                      // suffixIconColor: Colors.white,
                      // suffixIconSize: 18,
                      // prefixIconSize: 0,
                      // separateSuffixIcon: 5,
                      onPressed: () async {
                        // final body = {
                        //   // "customerId": widget.data['customerId'],
                        //   // "bp_code": widget.data['bp_code'],
                        //   // "equipmentId":widget.data['id'],
                        //   "service_type": requestType,
                        //
                        //   "priority": selectedValue ?? serviceTypes[1],
                        //   "service_date":  _dateController.text,
                        //   // "AMC": 0,
                        //   "remarks":  _remarksController.text,
                        // };
                        //
                        // print(body);
                        // await equipmentController.storeServiceRequest(context,body,);
                        Navigator.pop(context);
                      },
                    ),
                  ),
                ),
              )
              //   :Text('Kindly Book your Service At Service Screen')
            ],
          ),
        ),
      ),
    );
  }
}
