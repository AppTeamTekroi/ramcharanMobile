
import "package:flutter/material.dart";
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:ramcharan/Login/login_controller.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ramcharan/features/controllers/farmerController.dart';
import 'package:ramcharan/features/userController.dart';



import '../Login/loginScreen.dart';

import 'dashboard.dart';
import '../ui/Buttons/button.dart';
import '../ui/assets/app_assets.dart';
import '../ui/color/appColor.dart';
import 'FarmerRegistration.dart';
import 'NewCropRegister.dart';
import 'Profile.dart';
import 'farmerList.dart';




class BottomNav extends StatefulWidget {
  const BottomNav({Key? key}) : super(key: key);

  @override
  State<BottomNav> createState() => _BottomNavState();
}
class _BottomNavState extends State<BottomNav> {

  LoginController lc = Get.put(LoginController());
  UserController uc = Get.put(UserController());
  FarmerController farmer = Get.put(FarmerController());
  @override
  void initState() {
    super.initState();
    getUserName();
    farmer.farmerList(context);
    farmer.districtList(context);

  }
  int _selectedIndex = 0;
  bool _isProfileSelected = false;

  List<Widget> pages = [
    HomeScreen(),
    Farmerlist(fromCrop: false,),
    Profile(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
      _isProfileSelected = false;
      uc.pageNumber.value = index;
    });
  }
  Future<bool> _onWillPop() async {
    if (_selectedIndex != 0) {
      // If the current page is not the HomeScreen, navigate back to it.
      setState(() {
        _selectedIndex = 0;
      });
      uc.pageNumber.value = 0;
      return false; // Do not exit the app.
    }
    return true; // Exit the app if already on the HomeScreen.
  }
  String name = "Loading...";

  Future<void> getUserName() async {

    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? storedName = prefs.getString('name');
    print("Fetched Name from SharedPreferences: $storedName"); // Debug log

    setState(() {
      name = storedName ?? 'Unknown';
    });
    print("Updated Name in UI: $name"); // Debug log
  }
  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;


    return  PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, result) async {
          if (didPop) {
            return;
          }
          final navigator = Navigator.of(context);
          bool value = await _onWillPop();
          if (value) {
            navigator.pop(result);
          }
        },

        child:Scaffold(

          // appBar: AppBar(
          //   backgroundColor: Colors.white,
          //
          //   automaticallyImplyLeading: false,
          //   title: Row(
          //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //     children: [
          //       Row(
          //         children: [
          //           SizedBox(width: w*0.03),
          //
          //           Image.asset(AppImagePaths.applogo, width: 47, height: 20),
          //           SizedBox(width: w*0.02),
          //           Text(
          //             "SERVICE AND SUPPORT",
          //             style: GoogleFonts.oswald(
          //                 fontSize: 15, fontWeight: FontWeight.bold, color: Colors.grey.shade600),
          //           ),
          //         ],
          //       ), // Replace with your logo
          //       Padding(
          //         padding: EdgeInsets.symmetric(horizontal: w *0.0002),
          //         child: GestureDetector(
          //             onTap: ()=> showModalBottomSheet(
          //               isScrollControlled: true,
          //               context: context,
          //               builder: (context) => Padding(
          //                 padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          //                 child:  Notificationwidget(),
          //               ),
          //             ),
          //
          //             child:
          //             Stack(
          //               children: [
          //                 PopupMenuButton<int>(
          //                   color: Colors.white,
          //                   icon: Container(
          //                     decoration: BoxDecoration(
          //                         borderRadius: BorderRadius.circular(11),
          //                         color: AppColors.primary
          //                     ),
          //                     child: Icon(
          //                       Icons.add,
          //                       size: 25,
          //                       color: Colors.white,
          //                     ),
          //                   ), // Three-dot menu icon
          //                   onSelected: (value) {
          //                     if (value == 1) {
          //                       showBottomSheetWidget(
          //                           context,
          //                       Travelrequest()
          //                       );
          //                       print("Option 1 Clicked");
          //                     } else if (value == 2) {
          //                       print("Option 2 Clicked");
          //                     }else if (value == 3) {
          //                       print("Option 2 Clicked");
          //                     }else if (value == 4) {
          //                       print("Option 2 Clicked");
          //                     }
          //                   },
          //                   itemBuilder: (context) => [
          //                     PopupMenuItem(
          //                       value: 1,
          //                       child: Text("Travel Request",style: GoogleFonts.roboto(fontWeight: FontWeight.w500,fontSize: 15),),
          //                     ),
          //                     PopupMenuItem(
          //                       value: 2,
          //                       child: Text("Local Conveyance",style: GoogleFonts.roboto(fontWeight: FontWeight.w500,fontSize: 15),),
          //                     ),
          //
          //                   ],
          //                 )
          //
          //
          //                 // Image.asset(AppImagePaths.bell, height: h*0.09, width: w*0.05), // Bell icon
          //                 // Positioned(
          //                 //   right: 0,
          //                 //   top: 0,
          //                 //   child: Container(
          //                 //     width:  w*0.025, // Adjust size as needed
          //                 //     height:  h*0.08,
          //                 //     decoration: BoxDecoration(
          //                 //       color: Colors.red, // Notification dot color
          //                 //       shape: BoxShape.circle,
          //                 //     ),
          //                 //   ),
          //                 // ),
          //               ],
          //             )
          //         ),
          //       ),
          //     ],
          //   ),
          //   leading: Builder(
          //     builder: (context) => GestureDetector(
          //       onTap: () {
          //         Scaffold.of(context).openDrawer();
          //       },
          //       child: Padding(
          //         padding: EdgeInsets.all(18),
          //         child: Image.asset(AppImagePaths.menu, height: Get.height * 0.05, width: Get.width * 005),
          //       ),
          //     ),
          //   ),
          // ),

          body:  pages[_selectedIndex],




          bottomNavigationBar: Padding(
            padding: EdgeInsets.only(bottom: 30,left: Get.width*0.04 ,right: Get.width*0.04 ),
            child: Container(
              width: w * 0.75,
              height: h* 0.1,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(
                  right: BorderSide(
                    color: Colors.red,
                    width: 3,
                  ),
                  left:   BorderSide(
                    color: Colors.red,
                    width: 3,
                  ),
                ),      borderRadius: BorderRadius.circular(40), // This makes it pill-shaped
                // boxShadow: [
                // BoxShadow(
                // color: Colors.black12,
                // blurRadius: 10,
                // offset: Offset(0, 4),
                // )
                // ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  buildNavItem(Icons.home, 0,'Home'),
                  buildNavItem(Icons.people, 1,'Farmers'),
                  // buildNavItem(Icons.grass, 2,'Crop'),

                  buildNavItem(Icons.person, 2,'Profile'),
                ],
              ),
            ),
          ),
          backgroundColor: Colors.white,
        )
    );
  }

  Widget buildNavItem(IconData icon, int index, String name) {
    final isSelected = _selectedIndex == index;

    return GestureDetector(
      onTap: () => setState(() => _selectedIndex = index),
      child: Container(
        height: 50,
        child: Column(
          children: [
            Icon(
              icon,size: 25,
              color: isSelected ? Colors.red[900] : Colors.black54,
            ),
            Text(name,style: TextStyle(fontSize: 12),)
          ],
        ),
      ),
    );
  }
}



// void showBottomSheetWidget(BuildContext context, Widget childWidget) {
//   showModalBottomSheet(
//     isScrollControlled: true,
//     context: context,
//     builder: (context) => Padding(
//       padding:
//       EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
//       child: childWidget,
//     ),
//   );
// }
//
//
// Widget _buildNavIcon(String assetPath, bool isActive) {
//   return ColorFiltered(
//     colorFilter: ColorFilter.mode(
//       isActive ? AppColors.primary : AppColors.text,
//       BlendMode.srcIn,
//     ),
//     child: Image.asset(
//       assetPath,
//       width: 24,
//       height: 24,
//     ),
//   );
// }
