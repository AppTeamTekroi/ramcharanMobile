import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:multi_dropdown/multi_dropdown.dart';
import 'package:http/http.dart' as http;
import 'package:quickalert/quickalert.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ramcharan/Login/login_controller.dart';
import 'package:ramcharan/features/source/source.dart';
import 'package:ramcharan/ui/Buttons/button.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/headerfiles.dart';
import '../ui/color/appColor.dart';
import '../ui/loading.dart';
import '../ui/widgets/CommonWidget.dart';
import '../ui/widgets/richtext.dart';

import 'controllers/farmerController.dart';
import 'farmerList.dart';


class Newcropregister extends StatefulWidget {
  const Newcropregister({super.key});

  @override
  State<Newcropregister> createState() => _RecieptState();
}

class _RecieptState extends State<Newcropregister> {
  int? _selectedFarmerId;
  int? _selectedFarmerMobile;
  List<int> _selectedLandsId = [];
  String? _selectedFarmerName;
  String? _selectedFarmerCode;
  String? _selectedCollection;
  String? address;
  int? aadhaar;
   var weightcorrect = false.obs;
  var updatedetails = false.obs;
  TextEditingController name = TextEditingController();
  TextEditingController vehicalNo = TextEditingController();
  TimeOfDay? _startTime;
  TimeOfDay? _endTime;
  DateTime? _selectedDate;
  String _duration = "";

  Future<void> _launchURL(url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $url");
    }
  }
  List<Map<String, dynamic>> _newffbList = [];



  // final List<double> gross_wt = [];
  // final List<double> net_wt = [];
  // final List<double> tare_wt = [];
  // final List<double> rejected_wt = [];
  // final List<double> weight = [];
  final TextEditingController phoneController = TextEditingController();

  FarmerController controller = Get.put(FarmerController());
  LoginController lc = Get.put(LoginController());
  SourceImpl dc = Get.put(SourceImpl());
  late MultiSelectController<int> _landController;

  // final MultiSelectController<int> _landController = MultiSelectController<int>();


  @override
  void initState() {
    super.initState();
    _landController = MultiSelectController<int>();
  }

  @override
  void dispose() {
    _landController.dispose();
    super.dispose();
  }

  Future<void> _submitData() async {

    if (_selectedFarmerId == null || _newffbList.isEmpty ) {
      updatedetails.value = true;
      return;
    }
    if (name.text.isEmpty || phoneController.text.isEmpty || vehicalNo.text.isEmpty) {
      updatedetails.value = true;
      return;
    }
      for (int i = 0; i < _newffbList.length; i++) {
        final land = _newffbList[i];
        if (land['grossWeight'] == null ||
            land['tareWeight'] == null ||
            land['netWeight'] == null ||
            land['rejectedWeight'] == null) {
          updatedetails.value = true;
          return;

        }
      }



    LoadingOverlay.show('Processing ...');

      List<double> grossWt = _newffbList
        .map<double>((land) => (land['grossWeight'] ?? 0).toDouble())
        .toList();
    List<double> tareWt = _newffbList
        .map<double>((land) => (land['tareWeight'] ?? 0).toDouble())
        .toList();
    List<double> netWt = _newffbList
        .map<double>((land) => (land['netWeight'] ?? 0).toDouble())
        .toList();
    List<double> rejectedWt = _newffbList
        .map<double>((land) => (land['rejectedWeight'] ?? 0).toDouble())
        .toList();

    List<double> finalWt = [];


    List<String> startTime = _newffbList
        .map<String>((land) => (land['_startTime'] ?? "00:00"))
        .toList();
    List<String> endTime = _newffbList
        .map<String>((land) => (land['_endTime'] ?? "00:00"))
        .toList();


    for (int i = 0; i < _newffbList.length; i++) {
      finalWt.add(netWt[i] - rejectedWt[i]);
    }
    SharedPreferences _pref = await SharedPreferences.getInstance();
    final loginId = _pref.getInt('userId');
    final body = {
      "farmer_id": _selectedFarmerId,
      "field_officer": loginId,
      "farmer_code": _selectedFarmerCode,
      "farmer_mobile": _selectedFarmerMobile,
      "center" : _selectedCollection,
      "gross_wt": grossWt,
      "tare_wt": tareWt,
      "net_wt": netWt,
      "rejection_wt": rejectedWt,
      "final_wt": finalWt,
      "startTime" : startTime,
      "endTime": endTime,
      'driver_name'   : name.text,
      'vehicle_no'    : vehicalNo.text,
      'driver_mobile' : phoneController.text,

    };
    print(body);
    final response = await dc.postCropCollection(context,body);

    LoadingOverlay.hide();

    response.fold(
          (failure){
        QuickAlert.show(
          context: Get.context!,
          type: QuickAlertType.error,
          title: "Error",
          text: failure.message,
        );
      },
          (data) {
            QuickAlert.show(
              context: Get.context!,
              type: QuickAlertType.success,
              title: "Success",
              text: "FFB Data Updated successfully!",
              confirmBtnText: "Receipt",
              cancelBtnText: "Close",
              showCancelBtn: true,

              onConfirmBtnTap: () async {
                Get.back(); // close alert
                if (data["pdf"] != null && data["pdf"] != '') {
                  _launchURL(data["pdf"]);
                } else {
                  Get.snackbar("Error", "PDF link is missing");
                }
              },
              onCancelBtnTap: () {
                Get.back(); // just close the alert
              },
            );

            setState(() {
          _selectedFarmerId = null;
          _newffbList.clear();
          _landController.clearAll();
          _selectedFarmerName = null;
          _selectedFarmerMobile=null;
          address = null;
          aadhaar = null;
        });
      },
    );

  }


  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(

        leadingWidth: 40,
        backgroundColor: AppColors.primary,
        title: Text("FFB Collection",style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold),),
        centerTitle: true,
        iconTheme: const IconThemeData(
          color: Colors.white, // ✅ makes the back arrow white
        ),      ),
      body:  Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18,vertical: 21 ),

        child:SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  Text(
                    'Farmer',
                    style: TextStyle(
                        color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600),
                  ),
                  SizedBox(
                    width: 5,
                  ),
                  Icon(
                    Icons.info,
                    size: 18,
                    color: Colors.black54,
                  )
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              GestureDetector(
                  onTap: () async {
                    // Navigate to Farmerlist page and wait for selected data
                    final selectedFarmer = await Get.to(() => const Farmerlist(fromCrop: true,));

                    if (selectedFarmer != null && selectedFarmer['farmer_code'] != '') {
                      setState(() {
                        _selectedFarmerId = selectedFarmer['id'];
                        _selectedFarmerName = selectedFarmer['farmer_name']; // new variable
                        _selectedFarmerCode = selectedFarmer['farmer_code'] ?? ''; // new variable
                        _selectedCollection = selectedFarmer['collection_center'] ?? ''; // new variable
                        _selectedFarmerMobile = selectedFarmer['farmer_mobile'] ?? '';
                        // address = selectedFarmer['address'];
                        // aadhaar = selectedFarmer['aadhaar_no'];
                        // final farmerData = controller.filteredList.firstWhere(
                        //       (f) => f['id'] == _selectedFarmerId,
                        //   orElse: () => {},
                        // );

                        // final lands = (farmerData['lands'] as List<dynamic>? ?? []);
                        // final items = lands
                        //     .map((land) => DropdownItem<int>(
                        //   value: land['id'] as int,
                        //   label: land['land_name'] as String,
                        // ))
                        //     .toList();
                        //
                        // // // clear previous selections and set new items
                        // _landController.clearAll();
                        // _landController.setItems(items);

                        print("Selected Farmer ID: $_selectedFarmerId");
                        // print("Lands loaded: $lands");
                      });
                    }
                  },
                  child:
                  Container(
                    width: w,
                    // Height depends on whether farmer is selected or not
                    // height: _selectedFarmerName == null ? h * 0.06 : h * 0.1,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              _selectedFarmerName ?? "Select Farmer",
                              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
                              overflow: TextOverflow.ellipsis,
                            ),
                            // Show aadhaar only if available
                            // if (aadhaar != null)
                            //   Text(
                            //     aadhaar.toString(),
                            //     style: const TextStyle(fontSize: 12, color: Colors.black),
                            //     overflow: TextOverflow.ellipsis,
                            //   ),
                            // // Show address only if available
                            // if (address != null && address!.isNotEmpty)
                            //   Text(
                            //     address!,
                            //     style: const TextStyle(fontSize: 12, color: Colors.black),
                            //     overflow: TextOverflow.ellipsis,
                            //   ),
                          ],
                        ),
                        const Icon(Icons.keyboard_arrow_right, color: Colors.black, size: 28),
                      ],
                    ),
                  )
              ),
              const SizedBox(
                height: 15,
              ),
              Text(
                'Driver Details',
                style: TextStyle(
                    color: Colors.black,fontSize: 12, fontWeight: FontWeight.w600),
              ),
              CommonWidget(
                color: Colors.white,
                child: TextField(
                  controller: name,
                  keyboardType: TextInputType.text,

                  decoration: InputDecoration(
                    hintText: 'Driver Name',
                    hintStyle: TextStyle(fontSize: 14,color: Colors.grey.shade400,),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 10),
                  ),
                ),
              ),


                  CommonWidget(
                    color: Colors.white,

                    // width: h * 0.5,
                    child: TextField(
                      controller: vehicalNo,
                      keyboardType: TextInputType.text,
                      decoration: InputDecoration(
                        hintText: 'Vehicle Number',
                        hintStyle: TextStyle(fontSize: 14,color: Colors.grey.shade400,
                        ),

                        border: InputBorder.none,
                        contentPadding:
                        const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 10),
                      ),
                    ),
                  ),


              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    // border:
                    // Border.all(color: Colors.grey.shade300),
                  ),
                  child: IntlPhoneField(
                    showDropdownIcon: false,
                    showCountryFlag: false,
                    disableLengthCheck: true, // we control it
                    flagsButtonPadding: const EdgeInsets.all(8),
                    dropdownIconPosition: IconPosition.trailing,
                    initialCountryCode: 'IN',
                    keyboardType: TextInputType.number,
                    // inputFormatters: <TextInputFormatter>[
                    //   FilteringTextInputFormatter
                    //       .digitsOnly, // only numbers
                    //   LengthLimitingTextInputFormatter(
                    //       10), // max 10 digits
                    // ],
                    decoration: InputDecoration(
                      counterText:
                      "", // hides the length counter
                      contentPadding:
                      const EdgeInsets.symmetric(
                          vertical: 12, horizontal: 12),
                      hintText: 'Driver Phone Number',
                      hintStyle: TextStyle(
                        fontWeight: FontWeight.normal,
                        fontSize: 14,
                        color: Colors.grey.shade400,
                      ),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                      ),
                    ),
                    onChanged: (phone) {
                      phoneController.text = phone.number;
                    },
                  ),
                ),
              ),
              const SizedBox(
                height: 15,
              ),

              Row(
                children: [
                  Text(
                    'FFB Details',
                    style: TextStyle(
                        color: Colors.black,fontSize: 12, fontWeight: FontWeight.w600),
                  ),
                  Spacer(),
                  GestureDetector(onTap: (){

                    _newffbList.add({
                      "grossWeight" :null,
                      "tareWeight" :null,
                      "rejectedWeight" :null,
                    });
                    final newIndex = _newffbList.length - 1;

                    _showEditBottomSheet(context,
                        {
                          "grossWeight" :null,
                          "tareWeight" :null,
                          "rejectedWeight" :null,
                        },newIndex);

                  },child: Icon(Icons.add_box,color: Colors.red,),),
                ],
              ),


              const SizedBox(height: 16),
             if(_newffbList.isNotEmpty)
              ListView.builder(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: _newffbList.length,
                itemBuilder: (context, index) {
                  final land = _newffbList[index];
                  return Container(
                    padding:
                    const EdgeInsets.symmetric(horizontal: 4),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child:  Container(
                        margin: const EdgeInsets.symmetric(
                            horizontal: 4),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 4),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius:
                          BorderRadius.circular(10),
                        ),
                        child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 15.0,vertical: 7),
                            child: Column(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment
                                        .spaceBetween,
                                    children: [
                                       Text("Load Number - ${(index+1).toString()}",
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight:
                                            FontWeight.w600,
                                            color: Colors
                                                .orange[900]),
                                        overflow: TextOverflow
                                            .ellipsis,
                                      ),

                                      RichText(
                                        text: TextSpan(
                                          text: '${land['finalWeight'] ?? 0.0}', // label
                                          style: const TextStyle(
                                            color: Colors.green,
                                            fontWeight: FontWeight.bold,
                                          ),
                                          children: [
                                            TextSpan(
                                              text: " kg", // formatted value
                                              style: const TextStyle(
                                                color: Colors.grey,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 11,
                                              ),
                                            ),
                                          ],
                                        ),
                                      )


                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text("Entry:  ${( land['_startTime'] ?? "--").toString()}"),
                                        Text("Exit:  ${( land['_endTime'] ?? "--").toString()}"),
                                    ],
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal:0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            const Text('Gross Weight'),
                                            Text(
                                              (land['grossWeight'] ?? "--").toString(),
                                            ),
                                          ],
                                        ),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            const Text('Tare Weight'),
                                            Text(
                                              (land['tareWeight'] ?? "--").toString(),
                                            ),
                                          ],
                                        ),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            const Text('Rejected Weight'),
                                            Text(
                                              (land['rejectedWeight'] ?? "--").toString(),
                                            ),
                                          ],
                                        ),
                                        // Row(
                                        //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        //   children: [
                                        //     const Text('Net Weight'),
                                        //     Text(
                                        //       (land['netWeight'] ?? "--").toString(),
                                        //     ),
                                        //   ],
                                        // ),


                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            GestureDetector(
                                                onTap: () {

                                                  setState(() {
                                                    _newffbList.removeAt(index); // ✅ remove by index
                                                  });                                                }, child: Text("Remove",style: TextStyle(color: Colors.lightBlue.shade900),

                                            )),
                                            GestureDetector(
                                            onTap: () {
                                              _showEditBottomSheet(context, land,index);
                                            }, child: Text("Update ➤",style: TextStyle(color: Colors.red.shade900),

                                            ))

                                          ],
                                        ),


                                        const SizedBox(height: 6),
                                        // Text("Gross: ${land['grossWeight'] ?? ""}"),
                                        // Text("Net: ${land['netWeight'] ?? ""}"),
                                        // Text("Tare: ${land['tareWeight'] ?? ""}"),
                                        // Text("Rejected: ${land['rejectedWeight'] ?? ""}"),
                                        // Text("Final: ${land['finalWeight'] ?? ""}"),
                                        // // leave space for edit button
                                      ],
                                    ),
                                  ),

                                  // Cross icon (top right)
                                  //  IconButton(
                                  //     icon: const Icon(Icons.close, color: Colors.black),
                                  //     onPressed: () {
                                  //       setState(() {
                                  //         _selectedLands.remove(land);
                                  //       });
                                  //     },
                                  //   ),


                                  // Edit icon (bottom right)


                                ] )
                        )
                    ),

                  );
                },
              ),


            ],
          ),
        ),

      ),
      bottomNavigationBar: Container(height: 80,
        decoration: const BoxDecoration(color: Colors.white),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10),
          child:


      Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Obx(()=>updatedetails.value
              ? Text('🔺Update the weight\ndetail against ffb')
              :SizedBox.shrink()
          ),
          ButtonBS(
            onPressed: _submitData,
            width: w*0.5,
            title: 'Store Collection',
            textColor: Colors.white,
            fontSize: 14,
            fontWeight: FontWeight.w600,
            padding: 6.0,
            backgroundColor: AppColors.primary,
            borderRadius: 10,
          ),
        ],
      ),
        ),
          ),
    );
  }

  // void _calculateDuration() {
  //   if (_startTime != null && _endTime != null) {
  //     final start = Duration(hours: _startTime!.hour, minutes: _startTime!.minute);
  //     final end = Duration(hours: _endTime!.hour, minutes: _endTime!.minute);
  //     final diff = end - start;
  //
  //     if (diff.inMinutes >= 0) {
  //       final hours = diff.inHours;
  //       final minutes = diff.inMinutes.remainder(60);
  //       _duration = '${hours}h ${minutes}m';
  //     } else {
  //       _duration = 'Invalid Time';
  //     }
  //   }
  // }

  void _showEditBottomSheet(BuildContext context, Map<String, dynamic> land, int index) {

      final grossController = TextEditingController(
          text: land['grossWeight'] != null ? land['grossWeight'].toString() : "");
      final tareController = TextEditingController(
          text: land['tareWeight'] != null ? land['tareWeight'].toString() : "");
      final rejectedController = TextEditingController(
          text: land['rejectedWeight'] != null ? land['rejectedWeight'].toString() : "");

      final netController = TextEditingController(
          text: (land['grossWeight'] != null && land['tareWeight'] != null)
              ? (land['grossWeight'] - land['tareWeight']).toString()
              : "");
      final finalController = TextEditingController(
          text: (land['grossWeight'] != null &&
              land['tareWeight'] != null &&
              land['rejectedWeight'] != null)
              ? ((land['grossWeight'] - land['tareWeight']) -
              land['rejectedWeight'])
              .toString()
              : "");

      void _updateGross(StateSetter setModalState) {
        final gross = double.tryParse(grossController.text) ?? 0;
        final tare = double.tryParse(tareController.text) ?? 0;
        final rejected = double.tryParse(rejectedController.text) ?? 0;

        setModalState(() {
          if (grossController.text.isNotEmpty || tareController.text.isNotEmpty) {
           double net = gross - tare;
           if (net < 0) net = 0;
           netController.text = net.toString();
          }
          if (netController.text.isNotEmpty || rejectedController.text.isNotEmpty) {

            double afterrej = ((double.tryParse(netController.text) ?? 0) - rejected);
            if(afterrej < 0) afterrej = 0;
            finalController.text = afterrej.toString();
          }
        });
      }

      showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      isDismissible: false,
      enableDrag: false,
        backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            netController.addListener(() => _updateGross(setModalState));
            tareController.addListener(() => _updateGross(setModalState));
            rejectedController.addListener(() => _updateGross(setModalState));



            void _pickStartTime(BuildContext context) async {
              final TimeOfDay? picked = await showTimePicker(
                context: context,
                initialTime: _startTime ?? TimeOfDay.now(),
                builder: (BuildContext context, Widget? child) {
                  return MediaQuery(
                    data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: false),
                    child: child!,
                  );
                },
              );
              if (picked != null) {
                setModalState(() {
                  _startTime = picked;
                });
              }
            }

            void _pickEndTime(BuildContext context) async {
              final TimeOfDay? picked = await showTimePicker(
                context: context,
                initialTime: _endTime ?? TimeOfDay.now(),
                builder: (BuildContext context, Widget? child) {
                  return MediaQuery(
                    data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: false),
                    child: child!,
                  );
                },
              );
              if (picked != null) {
                setModalState(() {
                  _endTime = picked;
                });
              }
            }

            return DraggableScrollableSheet(
              expand: false,
              initialChildSize: 0.6,
              minChildSize: 0.4,
              maxChildSize: 0.9,
              builder: (context, scrollController) {
                return Padding(
                  padding: EdgeInsets.only(
                    bottom: MediaQuery.of(context).viewInsets.bottom,
                    top: 16.0,
                    left: 16.0,
                    right: 16.0,
                  ),
                  child: SingleChildScrollView(
                    child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Header
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Text("Load Number - ${(index+1).toString()}",
                                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                ),
                              ),
                              IconButton(
                                onPressed: () {
                                  if(grossController.text.isEmpty) {
                                    _newffbList.removeLast();
                                  }
                                  Navigator.of(context).pop();
                                },
                                icon: const Icon(Icons.clear),
                              )
                            ],
                          ),
                          // Text(
                          //     widget.cardcode ,
                          //   style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                          //   overflow: TextOverflow.ellipsis,
                          //   maxLines: 1,
                          // ),

                          const Divider(thickness: 1, color: Colors.grey),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [

                                  Text("Weigh Bridge Entry Time:   "),
                                  Spacer(),

                                  GestureDetector(
                                    onTap: () => _pickStartTime(context),
                                    child: Container(
                                      padding: EdgeInsets.symmetric(vertical: 7, horizontal: 10),
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        border: Border.all(color: Colors.grey),

                                        borderRadius: BorderRadius.circular(10),
                                        // border: Border.all(color: Colors.black, width: 1),
                                      ),
                                      child: Row(
                                        //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          // Icon(Icons.alarm,color: Colors.black,size: 17,),
                                          //  SizedBox(width: 1),
                                          Text(
                                            _startTime != null
                                                ? _startTime!.format(context)
                                                : "00.00",
                                            style: TextStyle(fontSize: 12,color: Colors.black),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 5,),
                              Row(
                                children: [
                                  Text("Weigh Bridge Exit Time:   "),
Spacer(),
                                  GestureDetector(
                                    onTap: () => _pickEndTime(context),
                                    child: Container(

                                      padding: EdgeInsets.symmetric(vertical: 7, horizontal: 10),
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        border: Border.all(color: Colors.grey),

                                        borderRadius: BorderRadius.circular(10),
                                        // border: Border.all(color: Colors.black, width: 1),
                                      ),
                                      child: Row(
                                        //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          // Icon(Icons.alarm,color: Colors.black,size: 17,),
                                          // SizedBox(width: 2,),
                                          Text(
                                            _endTime != null
                                                ? _endTime!.format(context)
                                                : "00.00",
                                            style: TextStyle(fontSize: 12,color: Colors.black),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),



                          SizedBox(height: 10,),
                          // Fields
                          _buildRowField("Gross Weight", grossController),
                          const SizedBox(height: 12),
                          _buildRowField("Tare Weight", tareController),
                          const SizedBox(height: 12),
                          _buildRowField("Rejected Weight", rejectedController),

                          const SizedBox(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Net Weight'),
                              Text("${netController.text}kg"),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Total Weight'),
                              Text("${finalController.text}kg"),
                            ],
                          ),

                          Obx(() => weightcorrect.value
                              ? const Text("Please Update the fields Accurately")
                              : const SizedBox.shrink()
                          ),

                          const SizedBox(height: 30),
                          ButtonBS(
                            onPressed: () {
                              final tare = double.tryParse(tareController.text) ?? 0;
                              final net = double.tryParse(netController.text) ?? 0;
                              final rejected = double.tryParse(rejectedController.text) ?? 0;
                              final gross = double.tryParse(grossController.text) ?? 0;
                              final finalW = double.tryParse(finalController.text) ?? 0;
//(tare > net) ||
                              // Validation check
                              if ( (gross <= tare)||(rejected > net || tare == 0 || gross == 0) || (net != gross - tare)) {
                                weightcorrect.value = true; // <-- correct
                                return;
                              }
                              if (_startTime == null || _endTime == null) {
                                weightcorrect.value = true; // <-- correct
                                return;
                              }
                              setState(() {
                                _newffbList[index]['netWeight'] = net;
                                _newffbList[index]['tareWeight'] = tare;
                                _newffbList[index]['rejectedWeight'] = rejected;
                                _newffbList[index]['grossWeight'] = gross;
                                _newffbList[index]['finalWeight'] = finalW;
                                _newffbList[index]['_startTime'] = _startTime!.format(context);
                                _newffbList[index]['_endTime'] = _endTime!.format(context);


                              });

                              weightcorrect.value = false;

                              Navigator.pop(context);
                            },
                            title: 'Update ffb Weights',
                            textColor: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            padding: 14.0,
                            backgroundColor: AppColors.primary,
                            borderRadius: 15,
                          ),
                        ]
                    ),
                  ),
                );
              },
            );
          },
        );
      },
    );
  }


  Widget _buildRowField(String label, TextEditingController controller,
      {bool readOnly = false}) {
    return Row(
      children: [
        Expanded(
          child: TextField(
            controller: controller,
            readOnly: readOnly,
            decoration: InputDecoration(
              hint: Text(label),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
            ),
            keyboardType: TextInputType.number,
          ),
        ),
      ],
    );
  }

  // Widget _buildHighlightBox(String label, String value) {
  //   return Container(
  //
  //     padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 5),
  //     decoration: BoxDecoration(
  //       color: Colors.grey.shade300,
  //       borderRadius: BorderRadius.circular(12),
  //
  //     ),
  //     child: Column(
  //       crossAxisAlignment: CrossAxisAlignment.start,
  //       children: [
  //         Text(
  //           label,
  //           style: const TextStyle(
  //             fontWeight: FontWeight.bold,
  //             fontSize: 12,
  //             color: Colors.black,
  //           ),
  //         ),
  //         const SizedBox(height: 4),
  //         Text(
  //           value.isEmpty ? "0" : value,
  //           style: const TextStyle(
  //             fontSize: 12,
  //             fontWeight: FontWeight.w600,
  //             color: Colors.black87,
  //           ),
  //         ),
  //       ],
  //     ),
  //   );
  // }

}