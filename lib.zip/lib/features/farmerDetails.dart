import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ramcharan/features/controllers/farmerController.dart';
import 'package:url_launcher/url_launcher.dart';
import '../ui/color/appColor.dart';

import '../ui/widgets/CommonWidget.dart';
import '../ui/widgets/richtext.dart';

class Farmerdetails extends StatefulWidget {
  final dynamic data;
  final int farmerId;

  const Farmerdetails({super.key, this.data, required this.farmerId});

  @override
  State<Farmerdetails> createState() => _FarmerdetailsState();
}

class _FarmerdetailsState extends State<Farmerdetails> {
  FarmerController fc = Get.put(FarmerController());

  @override
  void initState(){
    super.initState();
      fc.farmerCropDetails(context, widget.farmerId,"farmer");

  }

  Future<void> _launchURL(url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $url");
    }
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.grey.shade200,

      appBar: AppBar(
          iconTheme: const IconThemeData(
            color: Colors.white, // ✅ makes the back arrow white
          ),
          backgroundColor: AppColors.primary,
          title:Text('Farmer Overview',style: TextStyle(fontSize: 22, fontWeight: FontWeight.w400,color: Colors.white),)




      ),



      body:  SingleChildScrollView(
        child: Container(
          width: width,

          padding: const EdgeInsets.symmetric(horizontal: 15.0,vertical: 5),

          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            // border: Border.all(
            // color: Colors.grey.shade300, width: 1),
            // color: Colors.white
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [

              Padding(
                padding: const EdgeInsets.only(top: 10.0),
                child: const Row(
                  children: [
                    Text(
                      'Farmer',
                      style: TextStyle(
                          color: Colors.black, fontWeight: FontWeight.w600),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Icon(
                      Icons.info,
                      size: 18,
                      color: Colors.black54,
                    )
                  ],
                ),
              ),

              // CommonRichText(
              //   label: 'Variety',
              //   value: data['varieties'],
              // ),
              Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(
                        color: Colors.grey.shade300, width: 1),
                    color: Colors.white
                ),

                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        CommonRichText(
                          label: 'Farmer',
                          value: widget.data['farmer_name'] ?? '--',
                        ),

                        CommonRichText(
                          label: 'Aadhaar',
                          value: widget.data['aadhaar_no'].toString(),
                        ),
                        CommonRichText(
                          label: 'Mobile',
                          value: widget.data['farmer_mobile'].toString(),
                        ),
                        CommonRichText(
                          label: 'Address',
                          value: "${widget.data["village"] ?? ''},${widget.data["mandal"?? '']},${widget.data["district"] ?? ''}"
                        ),
                        CommonRichText(
                          label: 'Collection Center',
                          value: widget.data['collection_center'].toString(),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8.0),
                          child: Text("Linked Bank : "),
                        ),
                        CommonRichText(
                          label: 'Bank Name',
                          value: widget.data['bank_name'].toString(),
                        ),
                        CommonRichText(
                          label: 'A/c No',
                          value: widget.data['account_no'].toString(),
                        ),
                        CommonRichText(
                          label: 'IFSC Code',
                          value: widget.data['ifsc_code'].toString(),
                        ),
                      ]),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10.0),
                child: const Row(
                  children: [
                    Text(
                      'Lands',
                      style: TextStyle(
                          color: Colors.black, fontWeight: FontWeight.w600),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Icon(
                      Icons.info,
                      size: 18,
                      color: Colors.black54,
                    )
                  ],
                ),
              ),
              if ((widget.data['lands'] as List).isNotEmpty)

                Container(
                  width: width,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(
                          color: Colors.grey.shade300, width: 1),
                      color: Colors.white
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: ListView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: (widget.data['lands'] as List).length,
                      itemBuilder: (context, index) {
                        final lands = widget.data['lands'] as List; // ✅ the whole list
                        final land = lands[index];                  // ✅ single land map
                        return Column(
                          children: [
                            if (index != 0) Divider(color: Colors.grey.shade300,),
                            CommonRichText(
                              label: 'Survey No',
                              value: land['survey_no'] ?? '',  // null check
                            ),

                            CommonRichText(
                              label: 'Aces',
                              value: land['acers'] ?? '',  // null check
                            ),
                            // CommonRichText(
                            //   label: 'Grade',
                            //   value: land['quality_grade'] ?? '',  // null check
                            // ),
                            CommonRichText(
                              label: 'Location',
                                value: "${widget.data["village"] ?? ''},${widget.data["mandal"?? '']},${widget.data["district"] ?? ''}"
                            ),
                          ],
                        );
                      },

                    ),
                  ),
                ),

              Padding(
                padding: const EdgeInsets.only(top: 10.0),
                child: const Row(
                  children: [
                    Text(
                      'FFB Collection',
                      style: TextStyle(
                          color: Colors.black, fontWeight: FontWeight.w600),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Icon(
                      Icons.info,
                      size: 18,
                      color: Colors.black54,
                    )
                  ],
                ),
              ),

              Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(
                        color: Colors.grey.shade300, width: 1),
                    color: Colors.white
                ),
                child: Obx(() {
                  if (fc.isLoading5.value) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (fc.errorMessage5.isNotEmpty) {
                    return Text(fc.errorMessage5.value, style: const TextStyle(color: Colors.red));
                  }
                  if (fc.cropData.isEmpty) {
                    return const Text("");
                  }

                  return ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: fc.cropData.length,
                    itemBuilder: (context, index) {
                      final crop = fc.cropData[index];
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8,vertical: 0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (index != 0) Divider(color: Colors.grey.shade300,),
                            // if (index != 0)SizedBox(height: 15,),
                            if(index == 0) SizedBox(height: 8,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(crop['receipt_id'].toString(),style: TextStyle(fontSize: 14,fontWeight: FontWeight.bold),),
                                Row(
                                  children: [
                                    // Text("Final Wt:",style: TextStyle(fontWeight: FontWeight.w600,fontSize: 14),),
                                    // SizedBox(width: 5,),
                                    Text(crop["final_wt"].toString())
                                  ],
                                )
                              ],
                            ),
                            // CommonRichText(label: "", value: crop['land_name'].toString()),

                            _buildRow("Gross Wt", crop['gross_wt'].toString()),
                            _buildRow("Tare Wt", crop['tare_wt'].toString()),
                            _buildRow("Net Wt", crop['net_wt'].toString()),
                            _buildRow("Rejected Wt", crop['rejection_wt'].toString()),
                            _buildRow("Driver",crop['driver'].toString() ),
                            _buildRow("Driver Contact", crop['driver_phone'].toString()),
                            _buildRow("Vehicle No", crop['vehicle_no'].toString()),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [




                                if (crop["pdf"] != null || crop["pdf"] == "")
                                  GestureDetector(
                                    onTap: () {

                                      if (crop[
                                      "pdf"] != null && crop[
                                      "pdf"] != '') {
                                        _launchURL(crop[
                                        "pdf"]);
                                      }
                                    },
                                    child: Row(
                                      children: [
                                        const Icon(
                                          Icons.link,
                                          color: Color(0xFFC09500),
                                        ),
                                        const SizedBox(width: 8),
                                        Text(
                                          'View PDF',
                                          // style: CommonWidget.,
                                        ),
                                      ],
                                    ),
                                  ),

                                // Text('Details')
                              ],
                            ),
                          ],
                        ),
                      );
                    },
                  );
                }),
              ),
              SizedBox(height: 20,)
            ],

          ),
        ),
      ),

    );

  }
  Widget _buildRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 1),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
              // fontWeight: FontWeight.bold,
              fontSize: 11,
            ),
          ),
          Flexible(
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 11,
                color: Colors.black87,
              ),
              textAlign: TextAlign.right,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

}