import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:ramcharan/features/salesReportpage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ramcharan/ui/assets/app_assets.dart';

import '../../ui/color/appColor.dart';
import '../Login/loginScreen.dart';
import '../Login/login_controller.dart';
import 'package:shimmer/shimmer.dart';

import 'CropList.dart';
import 'FarmerRegistration.dart';
import 'InventoryScreen.dart';
import 'NewCropRegister.dart';
import 'farmerList.dart';
import 'userController.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  UserController uc = Get.put(UserController());
  // final CustomerController controller = Get.put(CustomerController());

  // ProductController pc = Get.put(ProductController());
  LoginController lc = Get.put(LoginController());
  List<String> list = <String>['This Year', '2022', '2021', '2020'];
  String dropdownValue = 'This Year';
  String name = "Loading...";
  String eamil = "Loading...";

  // String currentDate = DateFormat('dd-MM-yyyy').format(DateTime.now());

  @override
  void initState() {
    super.initState();
    getUserName();
  }

  void getUserName() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? storedName = prefs.getString('name');
    String? storedemail = prefs.getString('email');

    print("Fetched Name from SharedPreferences: $storedName"); // Debug log

    setState(() {
      name = storedName ?? 'Hi !';
      eamil = storedName ?? '';
    });
    print("Updated Name in UI: $name"); // Debug log
  }

  List<String> names = [
    'Farmer Registration', // Simple and friendly for registration
    'Farmers Data', // Action-oriented and easy to understand
    'Create FBB', // Clear about entering weight data
    'View FFB Collection', // Understandable for checking previous entries
    'Reports',
    'Inventory Transfer',
  ];
//'Create FBB Receipt',       // Clear about entering weight data
//     'View Receipts',
  List<String> icons = [
    "lib/ui/assets/images/farmer.png",
    "lib/ui/assets/images/img.png",
    "lib/ui/assets/images/truckcrop.jpeg",
    "lib/ui/assets/images/wheat.png",
    "lib/ui/assets/images/report.jpeg",
    "lib/ui/assets/images/transfer.png",

  ];

  List<double> iconSizes = [
    50.0,
    50.0,
    50.0,
    50.0,
    50.0,
    30.0,
    // 40.0,
    // 40.0,
    // 40.0,
    // 40.0,
    // 40.0,
  ];

  //This variable to track whether the dialog was shown
  bool _dialogShown = false;

  // @override
  // void initState() {
  //   super.initState();
  //   WidgetsBinding.instance.addObserver(this);
  //    getUserName();
  //
  // }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // Reset the variable when the app is resumed
      _dialogShown = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    // controller.CustomerData(); // Load customer details
    // controller.CustomerBGData();

    // Format the current date
    // String currentDate = DateFormat('dd-MM-yyyy').format(DateTime.now());
    String currentDate = DateFormat('dd MMMM yyyy').format(DateTime.now());

    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;

    return Scaffold(
        backgroundColor: Colors.grey.shade200,
        appBar: AppBar(
          backgroundColor: AppColors.primary,
          automaticallyImplyLeading: false,
          title: Row(
            children: [
              CircleAvatar(
                radius: 17,
                backgroundColor: Colors.white,
                child:
                    Image.asset(AppImagePaths.applogo, width: 40, height: 25),
              ),
              SizedBox(
                width: 10,
              ),
              Text(
                'RAMCHARAN OIL INDUSTRIES',
                style: TextStyle(
                    fontSize: height*0.02,
                    fontWeight: FontWeight.w500,
                    color: Colors.white),
              )
            ],
          ),
          // leading: Builder(
          //   builder: (context) => GestureDetector(
          //     onTap: () {
          //       Scaffold.of(context).openDrawer();
          //     },
          //     child: Padding(
          //       padding: EdgeInsets.all(18),
          //       child: Image.asset(
          //         AppImagePaths.menu,
          //         height: Get.height * 0.05,
          //         width: Get.width * 005,
          //         color: Colors.white,
          //       ),
          //     ),
          //   ),
          // ),

          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: GestureDetector(
                onTap: () async {
                  await showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        backgroundColor: Colors.white,
                        content: const Text(
                          "Are you sure you want to logout?",
                          style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        actions: <Widget>[
                          TextButton(
                            child: Text(
                              "Yes",
                              style: TextStyle(
                                color: AppColors.primary,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            onPressed: () {
                              Get.off(()=>LoginScreen());
                              lc.logOutUser();

                            },
                          ),
                          TextButton(
                            child: Text(
                              "No",
                              style: TextStyle(
                                color: AppColors.primary,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            onPressed: () {
                              Navigator.of(context).pop(false);
                            },
                          ),
                        ],
                      );
                    },
                  );


                },
                child: Icon(
                  Icons.logout,
                  color: Colors.white.withOpacity(0.9),
                ),
              ),
            )
          ],
        ),
        body: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.all(0.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 0.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            CircleAvatar(
                              radius: 25,
                              backgroundColor: Colors.white70,
                              child: Icon(
                                Icons.person,
                                color: Colors.red,
                              ),

                              // Image.asset(AppImagePaths.applogo, fit: BoxFit.cover),
                            ),
                            SizedBox(width: width * 0.02),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  name,
                                  style: GoogleFonts.roboto(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.black),
                                ),
                                Text(
                                  "Hello, Welcome back to your account.",
                                  style: TextStyle(
                                      fontSize: 11, color: Colors.black),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      // const SizedBox(height: 6),
                      // Text(
                      //   eamil,
                      //   style: const TextStyle(
                      //     fontSize: 16,
                      //     color: Colors.black54,
                      //     fontWeight: FontWeight.w500,
                      //   ),
                      // ),
                      // const SizedBox(height: 12),
                      // Row(
                      //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      //   crossAxisAlignment: CrossAxisAlignment.start,
                      //   children: [
                      //     Column(
                      //       crossAxisAlignment: CrossAxisAlignment.start,
                      //
                      //       children: [
                      //         Text(
                      //           "Welcome back !",
                      //           style: const TextStyle(
                      //             fontSize: 20,
                      //             fontWeight: FontWeight.w500,
                      //           ),
                      //         ),
                      //         SizedBox(height: 10,),
                      //         Text(
                      //           name,
                      //           style: const TextStyle(
                      //             fontSize: 20,
                      //             fontWeight: FontWeight.w500,
                      //           ),
                      //         ),
                      //       ],
                      //     ),
                      //     const SizedBox(width: 6),
                      //     Text(
                      //       currentDate,
                      //       style: const TextStyle(
                      //         fontSize: 14,
                      //         fontWeight: FontWeight.w600,
                      //         color: Colors.grey,
                      //       ),
                      //     ),
                      //   ],
                      // ),
                    ],
                  ),
                ),

                // Stack(
                //   alignment: Alignment.bottomCenter,
                //   children: [
                //     Container(
                //       height: 170,
                //       child: PageView.builder(
                //         physics: BouncingScrollPhysics(),
                //         scrollDirection: Axis.horizontal,
                //         itemCount: 5,
                //         itemBuilder: (context, index) {
                //           return Padding(
                //             padding:
                //             const EdgeInsets.symmetric(horizontal: 8.0),
                //             child: Container(
                //               height: 75,
                //               width: MediaQuery.of(context).size.width * 0.86,
                //               decoration: BoxDecoration(
                //                 color: AppColors.mainblue,
                //                 borderRadius: BorderRadius.circular(12),
                //               ),
                //             ),
                //           );
                //         },
                //       ),
                //     ),
                //     Padding(
                //       padding: const EdgeInsets.only(bottom: 8.0),
                //       child: Container(
                //         height: 8,
                //         // width: 200,
                //         child: ListView.builder(
                //           physics: BouncingScrollPhysics(),
                //           scrollDirection: Axis.horizontal,
                //           itemCount: 5,
                //           shrinkWrap: true,
                //           itemBuilder: (context, index) {
                //             return Padding(
                //               padding:
                //               const EdgeInsets.symmetric(horizontal: 5.0),
                //               child: Container(
                //                 height: 5,
                //                 width: 8,
                //               ),
                //             );
                //           },
                //         ),
                //       ),
                //     ),
                //   ],
                // ),
                // Obx(() {
                //   if (controller.isLoading.value || controller.isLoading1.value) {
                //     return const Center(child: CircularProgressIndicator());
                //   }
                //
                //   if (controller.errorMessage.isNotEmpty || controller.errorMessage1.isNotEmpty) {
                //     return Center(
                //       child: Text(
                //         controller.errorMessage.isNotEmpty
                //             ? controller.errorMessage.value
                //             : controller.errorMessage1.value,
                //         style: const TextStyle(color: Colors.red),
                //       ),
                //     );
                //   }
                //
                //   final customer = controller.typedata['CustomerDetails']?.values?.first;
                //   final bg = controller.apidata['CustomerDetails']?.values?.     ;
                //
                //   return Column(
                //     crossAxisAlignment: CrossAxisAlignment.start,
                //     children: [
                //       // Toggle Buttons
                //       Container(
                //         child: ToggleButtons(
                //           isSelected: [
                //             controller.selectedCard.value == 0,
                //             controller.selectedCard.value == 1,
                //           ],
                //           onPressed: (index) {
                //             controller.selectedCard.value = index;
                //           },
                //           borderRadius: BorderRadius.circular(12),
                //           selectedColor: Colors.white,
                //           fillColor: AppColors.mainblue,
                //           children: const [
                //             Padding(
                //               padding: EdgeInsets.symmetric(horizontal: 20),
                //               child: Text('Customer Info'),
                //             ),
                //             Padding(
                //               padding: EdgeInsets.symmetric(horizontal: 20),
                //               child: Text('BG Details'),
                //             ),
                //           ],
                //         ),
                //       ),
                //      // const SizedBox(height: 16),
                //
                //       // Conditionally show cards
                //       if (controller.selectedCard.value == 0)
                //         Container(
                //           decoration: BoxDecoration(
                //               color: Colors.white,
                //               borderRadius: BorderRadius.circular(16)),
                //           child: Padding(
                //             padding: const EdgeInsets.all(8.0),
                //             child: Column(
                //               crossAxisAlignment: CrossAxisAlignment.start,
                //               children: [
                //                 const Text(
                //                   'Customer Info',
                //                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                //                 ),
                //                 const SizedBox(height: 12),
                //                 infoRow('0-60 Days', customer?['0-60 Days']),
                //                 infoRow('61-90 Days', customer?['61 to 90 Days']),
                //                 infoRow('91-120 Days', customer?['91 to 120 Days']),
                //                 infoRow('121+ Days', customer?['121 Plus Days']),
                //               ],
                //             ),
                //           ),
                //         )
                //       else
                //         Container(
                //           decoration: BoxDecoration(
                //               color: Colors.white,
                //               borderRadius: BorderRadius.circular(16)),
                //           child: Padding(
                //             padding: const EdgeInsets.all(8.0),
                //             child: Column(
                //               crossAxisAlignment: CrossAxisAlignment.start,
                //               children: [
                //                 const Text(
                //                   'BG Details',
                //                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                //                 ),
                //                 const SizedBox(height: 12),
                //                 infoRow(
                //                   'Expiry Date',
                //                   bg?['Expiry Date'] != null
                //                       ? DateTime.parse(bg!['Expiry Date']).toLocal().toString().split(' ')[0]
                //                       : 'N/A',
                //                 ),
                //                 infoRow('BG Value', bg?['BGValue']),
                //                 infoRow('BP Balance', bg?['BP_Bal']),
                //                 infoRow('Open SO Value', bg?['OpenSOVal']),
                //               ],
                //             ),
                //           ),
                //         ),
                //     ],
                //   );
                // }),

                SizedBox(
                  height: 20,
                ),

                // Container(
                //     height: 120,
                //     decoration: BoxDecoration(
                //         color: Colors.white,
                //         borderRadius: BorderRadius.circular(16)),
                //     child: Column(
                //       children: [
                //         Padding(
                //           padding:
                //           const EdgeInsets.symmetric(horizontal: 20.0),
                //           child: Row(
                //             children: [
                //               DropdownButton<String>(
                //                 value: dropdownValue,
                //                 icon: const Icon(
                //                     Icons.keyboard_arrow_down_outlined),
                //                 // elevation: -1,
                //                 // elevation: 16,
                //                 underline: Container(
                //                   height: 0,
                //                 ),
                //                 style: const TextStyle(color: Colors.black),
                //                 onChanged: (String? value) {
                //                   // This is called when the user selects an item.
                //                   setState(() {
                //                     dropdownValue = value!;
                //                   });
                //                 },
                //                 items: list.map<DropdownMenuItem<String>>(
                //                         (String value) {
                //                       return DropdownMenuItem<String>(
                //                         value: value,
                //                         child: Text(
                //                           value,
                //                           style: TextStyle(fontSize: 13),
                //                         ),
                //                       );
                //                     }).toList(),
                //               ),
                //               Spacer(),
                //               Text(
                //                 'View bills',
                //                 style: TextStyle(
                //                     color: AppColors.mainblue,
                //                     fontWeight: FontWeight.w500),
                //               )
                //             ],
                //           ),
                //         ),
                //
                //         Padding(
                //           padding:
                //           const EdgeInsets.symmetric(horizontal: 20.0),
                //           child: Row(
                //             // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //             children: [
                //               Column(
                //                 crossAxisAlignment: CrossAxisAlignment.start,
                //                 children: [
                //                   Text(
                //                     'Sales',
                //                     style: TextStyle(
                //                         color: Colors.grey,
                //                         fontWeight: FontWeight.w500),
                //                   ),
                //                   Text(
                //                     '400.00',
                //                     style: TextStyle(
                //                         color: Colors.black,
                //                         fontWeight: FontWeight.w600),
                //                   )
                //                 ],
                //               ),
                //               // SizedBox(
                //               //   width: width * 0.26,
                //               // ),
                //               // Row(
                //               //   children: [
                //               //     Container(
                //               //       height: 40,
                //               //       width: 1,
                //               //       decoration: BoxDecoration(
                //               //           color: Colors.grey.withOpacity(0.3)),
                //               //     ),
                //               //     SizedBox(
                //               //       width: 15,
                //               //     ),
                //               //     Column(
                //               //       crossAxisAlignment:
                //               //       CrossAxisAlignment.start,
                //               //       children: [
                //               //         Text(
                //               //           'Purchases',
                //               //           style: TextStyle(
                //               //               color: Colors.grey,
                //               //               fontWeight: FontWeight.w500),
                //               //         ),
                //               //         Text(
                //               //           '₹0.0',
                //               //           style: TextStyle(
                //               //               color: Colors.black,
                //               //               fontWeight: FontWeight.w600),
                //               //         )
                //               //       ],
                //               //     ),
                //               //   ],
                //               // )
                //             ],
                //           ),
                //         )
                //       ],
                //     )),
                // SizedBox(
                //   height: 20,
                // ),
                // SizedBox(
                //   height: 10,
                // ),
                // Obx(() => uc.expand.value
                //     ?

                Container(
                    // height: 160,
                    decoration: BoxDecoration(
                        // color: Colors.white,
                        borderRadius: BorderRadius.circular(16)),
                    child: Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: GridView.builder(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            mainAxisExtent: 112,
                            crossAxisSpacing: 5.0,
                            mainAxisSpacing: 25.0,
                          ),
                          // itemCount: pc.productDataList[0].listings!.length,
                          itemCount: 6,
                          itemBuilder: (context, index) => SizedBox(
                                height: 150,
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 4.0),
                                  child: GestureDetector(
                                    onTap: () {
                                      if (index == 0) {
                                        Navigator.push(
                                            context,
                                            (CupertinoPageRoute(
                                                builder: (context) =>
                                                    const FarmerRegistration())));
                                      }
                                      if (index == 1) {
                                        Navigator.push(
                                            context,
                                            (CupertinoPageRoute(
                                                builder: (context) =>
                                                    Farmerlist(
                                                      fromCrop: false,
                                                    ))));
                                      }
                                      if (index == 2) {
                                        Navigator.push(
                                            context,
                                            (CupertinoPageRoute(
                                                builder: (context) =>
                                                    const Newcropregister())));
                                      }
                                      if (index == 3) {
                                        Navigator.push(
                                            context,
                                            (CupertinoPageRoute(
                                                builder: (context) =>
                                                    Croplist())));
                                      }
                                      if (index == 4) {
                                        print('tapping');
                                        Navigator.push(
                                            context,
                                            (CupertinoPageRoute(
                                                builder: (context) =>
                                                    ReportListScreen())));
                                      }
                                      if (index == 5) {
                                        Navigator.push(
                                            context,
                                            (CupertinoPageRoute(
                                                builder: (context) =>
                                                    InventoryScreen())));
                                      }
                                    },
                                    child: Container(
                                      height: 100,
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(15),
                                          // border: Border.all(width: 1),
                                          color: Colors.white),
                                      child: Padding(
                                        padding: const EdgeInsets.all(10.0),
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Image.asset(
                                              icons[index],

                                              // color: AppColors.primary,
                                              height: iconSizes[index],
                                            ),
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            Text(
                                              names[index],
                                              style: const TextStyle(
                                                fontSize: 10,
                                                fontWeight: FontWeight.w500,
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              )),
                    )),





                SizedBox(height: height * 0.09), // Add spacing before the image
                Align(
                  alignment: Alignment.bottomRight,
                  child: Text(
                    'RAM.V0.4',
                    style: TextStyle(color: Colors.black),
                  ),
                ),
                //CustomerDetailsScreen(),
              ],
            ),
          ),
        ));
  }

  Widget infoRow(String label, dynamic value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            flex: 2,
            child: Text(
              "$label",
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.0),
            child: Text(': ', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
          Expanded(
            flex: 3,
            child: Text(value?.toString() ?? 'N/A'),
          ),
        ],
      ),
    );
  }
}
