import 'dart:ui';

// import 'package:firebase_core/firebase_core.dart';
// import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:ramcharan/Login/loginScreen.dart';
import 'package:ramcharan/Splash/SplashScreen.dart';
import 'package:ramcharan/ui/color/appColor.dart';

import 'Login/login_controller.dart';

import 'features/customerNavBar.dart';
import 'notification_service.dart';
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]).then((_) async{
    // await Firebase.initializeApp();
    //
    // await FirebaseMessaging.instance.requestPermission();
    // await initFCM();
    runApp(const MyApp());
  });
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  Future<bool> _checkLoginStatus() async {
    final LoginController loginController = Get.put(LoginController());
    await loginController.loadLoginState();
   return loginController.isLogin.value;
    // return {
    //   "isLogin": loginController.isLogin.value,
    //   "loginType": loginController.loginType ?? 1,
    // };
  }
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'ramcharan',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primary),
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false,


      home : FutureBuilder<bool>(
        future: _checkLoginStatus(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          } else {
            if (snapshot.hasData && snapshot.data == true) {
              return BottomNav();
            } else {
              return const LoginScreen();
            }
          }
        },
      ),

    );
  }
}




