import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:ramcharan/Login/loginScreen.dart';
import 'package:ramcharan/ui/color/appColor.dart';
import '../ui/Buttons/button.dart';
import '../ui/CommonBackground.dart';
import '../ui/assets/app_assets.dart';
class Splashscreen extends StatefulWidget {
  const Splashscreen({super.key});

  @override
  State<Splashscreen> createState() => _SplashscreenState();
}

class _SplashscreenState extends State<Splashscreen> {
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;

    return Scaffold(
      body: LoginBackground(
        child: Stack(
          children: [
            // Positioned.fill(
            //   child: Image.asset('lib/ui/assets/health.jpg', fit: BoxFit.cover),
            // ),

            // Radial Gradients
            // const BackgroundWidget(bottom: 0.75, right: 0.67, colors: [Color(0xFF46F080), Color(0xFF46F08A), Colors.white]),
            // const BackgroundWidget(bottom: 0.58, left: 0.7, colors: [Color(0xFF2555FF), Color.fromRGBO(37, 85, 255, 0.25), Colors.white]),
            // const BackgroundWidget(bottom: 0.36, right: 0.45, colors: [Color(0xFF46BDF0), Color.fromRGBO(70, 179, 240, 0.15), Colors.white]),
            // const BackgroundWidget(bottom: 0.86, left: 0.48, colors: [Color(0xFFF0B646), Color.fromRGBO(240, 203, 70, 0.15), Colors.white]),
            // const BackgroundWidget(top: 0.87, left: 0.4, colors: [Color(0xFFF0B646), Color.fromRGBO(240, 203, 70, 0.15), Colors.white]),

            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  height: height * 0.05,
                ),
                Image.asset(AppImagePaths.applogo,
                  height: height * 0.06,
                  width: width * 0.5,
                  fit: BoxFit.contain,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 20,top: 11),
                  child: Text("KESAN TO ENTREPRENEUR",style: GoogleFonts.oswald(
                      fontSize: 21,
                      fontWeight: FontWeight.bold
                      ,color: AppColors.white),),
                ),
                //const Spacer(),
                SizedBox(height: 25),
                Image.asset(AppImagePaths.loginScreenLogo1,
                  height: height * 0.35,
                  width: width * 0.72,
                  fit: BoxFit.contain,
                ),
                //const Spacer(),
                SizedBox(height: 40),
                Text("Easy way to manage\n service & support",style: GoogleFonts.oswald(fontSize: 30, fontWeight: FontWeight.bold,color: Colors.grey.shade600),),
                SizedBox(height: 10,),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text("This productive tool is designed to help\n             you better manage your\n      service and support conveniently",style: TextStyle(fontSize: 15,color: Colors.grey),),
                ),
                SizedBox(height: 20,),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: width * 0.075),
                  child: ButtonBS(
                    title: "Let's Start",
                    textColor: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    width: width * 0.8,
                    height: height * 0.055,
                    // width: width * 0.39,
                    // height: height * 0.04,
                    padding: 5.0,
                    backgroundColor: AppColors.primary,
                    borderRadius: 25,
                    // suffixIcon: Icons.arrow_forward_ios,
                    // suffixIconColor: Colors.white,
                    // suffixIconSize: 18,
                    // prefixIconSize: 0,
                    // separateSuffixIcon: 5,
                    onPressed: () async {
                      Get.to(()=> LoginScreen());
                    },
                  ),

                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}