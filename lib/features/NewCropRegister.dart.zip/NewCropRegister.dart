import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:multi_dropdown/multi_dropdown.dart';
import 'package:http/http.dart' as http;
import 'package:quickalert/quickalert.dart';
import 'package:ramcharan/ui/widgets/pdfview.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ramcharan/Login/login_controller.dart';
import 'package:ramcharan/features/source/source.dart';
import 'package:ramcharan/ui/Buttons/button.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/headerfiles.dart';
import '../ui/color/appColor.dart';
import '../ui/loading.dart';
import '../ui/widgets/CommonWidget.dart';
import '../ui/widgets/richtext.dart';

import 'controllers/farmerController.dart';
import 'customerNavBar.dart';
import 'farmerList.dart';

class NewCropRegister extends StatefulWidget {
  final Map<String, dynamic>? selectedFarmer;

  const NewCropRegister({
    super.key,
    this.selectedFarmer,
  });

  @override
  State<NewCropRegister> createState() => _RecieptState();
}

class _RecieptState extends State<NewCropRegister> {
  var selectedFarmerData;
  int? _selectedFarmerId;
  int? _selectedFarmerMobile;
  List<int> _selectedLandsId = [];
  String? _selectedFarmerName;
  String? _selectedFarmerCode;
  String? _selectedCollection;
  String? address;
  int? aadhaar;
  var weightcorrect = false.obs;
  var updatedetails = false.obs;
  TextEditingController name = TextEditingController();
  TextEditingController vehicalNo = TextEditingController();

  DateTime? _selectedDate;
  String _duration = "";

  @override
  void initState() {
    super.initState();

    if (widget.selectedFarmer != null &&
        (widget.selectedFarmer!['farmer_code'] ?? '').toString().isNotEmpty) {
      selectedFarmerData = widget.selectedFarmer;

      _selectedFarmerId = int.tryParse(selectedFarmerData!['id'].toString());

      _selectedFarmerName = selectedFarmerData!['farmer_name'];

      _selectedFarmerCode = selectedFarmerData!['farmer_code'];

      _selectedCollection = selectedFarmerData!['collection_center'];

      _selectedFarmerMobile =
          int.tryParse(selectedFarmerData!['farmer_mobile'].toString());

      // name.text = _selectedFarmerName ?? '';
      _newffbList.clear();
    }
  }

  @override
  void dispose() {
    name.dispose();
    vehicalNo.dispose();
    super.dispose();
  }

  Future<void> _launchURL(url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $url");
    }
  }

  List<Map<String, dynamic>> _newffbList = [];

  // final List<double> gross_wt = [];
  // final List<double> net_wt = [];
  // final List<double> tare_wt = [];
  // final List<double> rejected_wt = [];
  // final List<double> weight = [];
  final TextEditingController phoneController = TextEditingController();

  FarmerController controller = Get.find();
  LoginController lc = Get.find();
  // SourceImpl dc = Get.find();
  final SourceImpl dc = SourceImpl();

  // late MultiSelectController<int> _landController;

  // final MultiSelectController<int> _landController = MultiSelectController<int>();

  Future<void> _submitData() async {
    if (_selectedFarmerId == null || _newffbList.isEmpty) {
      updatedetails.value = true;
      return;
    }
    if (name.text.isEmpty ||
        phoneController.text.isEmpty ||
        vehicalNo.text.isEmpty) {
      updatedetails.value = true;
      return;
    }
    for (int i = 0; i < _newffbList.length; i++) {
      final land = _newffbList[i];
      if (land['grossWeight'] == null ||
          land['tareWeight'] == null ||
          land['netWeight'] == null ||
          land['rejectedWeight'] == null) {
        updatedetails.value = true;
        return;
      }
    }

    LoadingOverlay.show('Processing ...');

    List<double> grossWt = _newffbList
        .map<double>((land) => (land['grossWeight'] ?? 0).toDouble())
        .toList();
    List<double> tareWt = _newffbList
        .map<double>((land) => (land['tareWeight'] ?? 0).toDouble())
        .toList();
    List<double> netWt = _newffbList
        .map<double>((land) => (land['netWeight'] ?? 0).toDouble())
        .toList();
    List<double> rejectedWt = _newffbList
        .map<double>((land) => (land['rejectedWeight'] ?? 0).toDouble())
        .toList();

    List<double> finalWt = [];

    List<String> startTime = _newffbList
        .map<String>((land) => (land['_startTime'] ?? "00:00"))
        .toList();
    List<String> endTime = _newffbList
        .map<String>((land) => (land['_endTime'] ?? "00:00"))
        .toList();

    for (int i = 0; i < _newffbList.length; i++) {
      finalWt.add(netWt[i] - rejectedWt[i]);
    }
    SharedPreferences _pref = await SharedPreferences.getInstance();
    final loginId = _pref.getInt('userId');
    final body = {
      "farmer_id": _selectedFarmerId,
      "field_officer": loginId,
      "farmer_code": _selectedFarmerCode,
      "farmer_mobile": _selectedFarmerMobile,
      "center": _selectedCollection,
      "gross_wt": grossWt,
      "tare_wt": tareWt,
      "net_wt": netWt,
      "rejection_wt": rejectedWt,
      "final_wt": finalWt,
      "startTime": startTime,
      "endTime": endTime,
      'driver_name': name.text,
      'vehicle_no': vehicalNo.text,
      'driver_mobile': phoneController.text,
    };
    print(body);
    final response = await dc.postCropCollection(context, body);

    LoadingOverlay.hide();

    response.fold(
      (failure) {
        QuickAlert.show(
          context: Get.context!,
          type: QuickAlertType.error,
          title: "Error",
          text: failure.message,
        );
      },
      (data) {
        QuickAlert.show(
            context: Get.context!,
            type: QuickAlertType.success,
            title: "Success",
            text: "FFB Data Updated successfully!",
            confirmBtnText: "Receipt",
            cancelBtnText: "Close",
            showCancelBtn: true,
            onConfirmBtnTap: () async {
              if (data["pdf"] != null && data["pdf"] != '') {
                Get.offAll(() => pdfview(
                      pdf: data["pdf"],
                    ));
                // _launchURL(data["pdf"]);
              } else {
                Get.snackbar("Error", "PDF link is missing");
              }
            },
            onCancelBtnTap: () =>
                Get.offAll(() => BottomNav()) // just close the alert

            );
        controller.cropList(context);
        setState(() {
          _selectedFarmerId = null;
          _newffbList.clear();
          _selectedFarmerName = null;
          _selectedFarmerMobile = null;
          address = null;
          aadhaar = null;
        });
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    final w = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Color(0xFFF1F1F1),
      appBar: AppBar(
        leadingWidth: 40,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () => Get.back(),
        ),
        backgroundColor: AppColors.white,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("FFB Collection",
                style: GoogleFonts.openSans(
                    fontSize: 20, fontWeight: FontWeight.w500, wordSpacing: 0)),
            Text("Ramcharan Oil Industries",
                style: GoogleFonts.openSans(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    wordSpacing: 0,
                    color: Colors.grey)),
          ],
        ),
        centerTitle: true,
        iconTheme: const IconThemeData(
          color: Colors.grey, // ✅ makes the back arrow white
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 21),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // const Row(
              //   children: [
              //     Text(
              //       'Farmer',
              //       style: TextStyle(
              //           color: Colors.black, fontSize: 12, fontWeight: FontWeight.w600),
              //     ),
              //     SizedBox(
              //       width: 5,
              //     ),
              //     Icon(
              //       Icons.info,
              //       size: 18,
              //       color: Colors.black54,
              //     )
              //   ],
              // ),

              // const SizedBox(
              //   height: 10,
              // ),
              GestureDetector(
                  onTap: () async {
                    // Navigate to Farmerlist page and wait for selected data
                    selectedFarmerData = await Get.to(() => const Farmerlist(
                          fromCrop: true,
                        ));

                    if (selectedFarmerData != null &&
                        selectedFarmerData['farmer_code'] != '') {
                      setState(() {
                        _selectedFarmerId = selectedFarmerData['id'];
                        _selectedFarmerName =
                            selectedFarmerData['farmer_name']; // new variable
                        _selectedFarmerCode =
                            selectedFarmerData['farmer_code'] ??
                                ''; // new variable
                        _selectedCollection =
                            selectedFarmerData['collection_center'] ??
                                ''; // new variable
                        _selectedFarmerMobile =
                            selectedFarmerData['farmer_mobile'] ?? '';
                        print("Selected Farmer ID: $_selectedFarmerId");
                        // print("Lands loaded: $lands");
                      });
                    }
                  },
                  child: Container(
                    // height: 50,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: const [
                        BoxShadow(
                          blurRadius: 6,
                          color: Colors.black12,
                        )
                      ],
                    ),

                    child: Row(
                      spacing: 10,
                      // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Icon(Icons.add_circle_outline_rounded,
                            color: Colors.grey, size: 22),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              _selectedFarmerName ?? "Select Farmer",
                              style: const TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.w500),
                              overflow: TextOverflow.ellipsis,
                            ),
                            Text("tap to select/change farmer",
                                style: GoogleFonts.inter(
                                    fontSize: 10, color: Colors.grey)),
                            // Show aadhaar only if available
                            if (_selectedFarmerName != null)
                              Text(
                                "Farmer Code :${_selectedFarmerCode.toString()}",
                                style: TextStyle(
                                    fontSize: 12, color: Colors.blueGrey[700]),
                                overflow: TextOverflow.ellipsis,
                              ),

                            // Show address only if available
                            if (_selectedCollection != null &&
                                _selectedCollection!.isNotEmpty)
                              Text(
                                "Collection Center : ${_selectedCollection!}",
                                style: TextStyle(
                                    fontSize: 12, color: Colors.blueGrey[700]),
                                overflow: TextOverflow.ellipsis,
                              ),
                          ],
                        ),
                      ],
                    ),
                  )),
              const SizedBox(
                height: 15,
              ),
              Text(
                'Driver Details',
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 12,
                    fontWeight: FontWeight.w600),
              ),
              CommonWidget(
                color: Colors.white,
                child: TextField(
                  controller: name,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    hintText: 'Driver Name',
                    hintStyle: TextStyle(
                      fontSize: 14,
                      color: Colors.grey.shade400,
                    ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 10),
                  ),
                ),
              ),

              CommonWidget(
                color: Colors.white,
                // width: h * 0.5,
                child: TextField(
                  controller: vehicalNo,
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    hintText: 'Vehicle Number',
                    hintStyle: TextStyle(
                      fontSize: 14,
                      color: Colors.grey.shade400,
                    ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 10),
                  ),
                ),
              ),

              Padding(
                padding: const EdgeInsets.only(top: 0.0),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    // border:
                    // Border.all(color: Colors.grey.shade300),
                  ),
                  child: IntlPhoneField(
                    showDropdownIcon: false,
                    showCountryFlag: false,
                    disableLengthCheck: true, // we control it
                    flagsButtonPadding: const EdgeInsets.all(8),
                    dropdownIconPosition: IconPosition.trailing,
                    initialCountryCode: 'IN',
                    keyboardType: TextInputType.number,
                    // inputFormatters: <TextInputFormatter>[
                    //   FilteringTextInputFormatter
                    //       .digitsOnly, // only numbers
                    //   LengthLimitingTextInputFormatter(
                    //       10), // max 10 digits
                    // ],
                    decoration: InputDecoration(
                      counterText: "", // hides the length counter
                      contentPadding: const EdgeInsets.symmetric(
                          vertical: 12, horizontal: 12),
                      hintText: 'Driver Phone Number',
                      hintStyle: TextStyle(
                        fontWeight: FontWeight.normal,
                        fontSize: 14,
                        color: Colors.grey.shade400,
                      ),
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                      ),
                    ),
                    onChanged: (phone) {
                      phoneController.text = phone.number;
                    },
                  ),
                ),
              ),
              const SizedBox(
                height: 15,
              ),

              Row(
                children: [
                  Text(
                    'FFB Details',
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 12,
                        fontWeight: FontWeight.w600),
                  ),
                  Spacer(),
                  GestureDetector(
                    onTap: () {
                      _newffbList.add({
                        "grossWeight": null,
                        "tareWeight": null,
                        "rejectedWeight": null,
                      });
                      final newIndex = _newffbList.length - 1;
                      _showEditBottomSheet(
                          context,
                          {
                            "grossWeight": null,
                            "tareWeight": null,
                            "rejectedWeight": null,
                          },
                          newIndex);
                    },
                    child: Container(
                      padding:
                          EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(
                          color: Colors.red.shade50,
                          borderRadius: BorderRadius.circular(8)),
                      child: Text(
                        "ADD FFB ➕",
                        style: TextStyle(
                          color: AppColors.primary,
                          fontSize: 11,
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 16),
              if (_newffbList.isNotEmpty)
                ListView.separated(
                  separatorBuilder: (context, index) {
                    return const Divider(height: 2);
                  },
                  physics: NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: _newffbList.length,
                  itemBuilder: (context, index) {
                    final land = _newffbList[index];
                    return Container(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 4),
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 15.0, vertical: 7),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          "Load Number - ${(index + 1).toString()}",
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.orange[900]),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        RichText(
                                          text: TextSpan(
                                            text:
                                                '${land['finalWeight'] ?? 0.0}', // label
                                            style: const TextStyle(
                                              color: Colors.green,
                                              fontWeight: FontWeight.bold,
                                            ),
                                            children: [
                                              TextSpan(
                                                text: " kg", // formatted value
                                                style: const TextStyle(
                                                  color: Colors.grey,
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 11,
                                                ),
                                              ),
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                            "Entry:  ${(land['_startTime'] ?? "--").toString()}"),
                                        Text(
                                            "Exit:  ${(land['_endTime'] ?? "--").toString()}"),
                                      ],
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 0),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              const Text('Gross Weight'),
                                              Text(
                                                (land['grossWeight'] ?? "--")
                                                    .toString(),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              const Text('Tare Weight'),
                                              Text(
                                                (land['tareWeight'] ?? "--")
                                                    .toString(),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              const Text('Rejected Weight'),
                                              Text(
                                                (land['rejectedWeight'] ?? "--")
                                                    .toString(),
                                              ),
                                            ],
                                          ),
                                          // Row(
                                          //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          //   children: [
                                          //     const Text('Net Weight'),
                                          //     Text(
                                          //       (land['netWeight'] ?? "--").toString(),
                                          //     ),
                                          //   ],
                                          // ),

                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              GestureDetector(
                                                  onTap: () {
                                                    setState(() {
                                                      _newffbList.removeAt(
                                                          index); // ✅ remove by index
                                                    });
                                                  },
                                                  child: Text(
                                                    "Remove",
                                                    style: TextStyle(
                                                        color: Colors.lightBlue
                                                            .shade900),
                                                  )),
                                              GestureDetector(
                                                  onTap: () {
                                                    _showEditBottomSheet(
                                                        context, land, index);
                                                  },
                                                  child: Text(
                                                    "Update ➤",
                                                    style: TextStyle(
                                                        color: Colors
                                                            .red.shade900),
                                                  ))
                                            ],
                                          ),

                                          const SizedBox(height: 6),
                                        ],
                                      ),
                                    ),
                                  ]))),
                    );
                  },
                ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        height: 80,
        decoration: const BoxDecoration(color: Colors.white),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Obx(() => updatedetails.value
                  ? Text('🔺Update the weight\ndetail against ffb')
                  : SizedBox.shrink()),
              ButtonBS(
                onPressed: _submitData,
                width: w * 0.5,
                title: 'Store Collection',
                textColor: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w600,
                padding: 6.0,
                backgroundColor: AppColors.primary,
                borderRadius: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showEditBottomSheet(
      BuildContext context, Map<String, dynamic> land, int index) {
    TimeOfDay? _startTime = land['_startTimeRaw'];
    TimeOfDay? _endTime = land['_endTimeRaw'];

    final grossController =
        TextEditingController(text: land['grossWeight']?.toString() ?? '');
    final tareController =
        TextEditingController(text: land['tareWeight']?.toString() ?? '');
    final rejectedController =
        TextEditingController(text: land['rejectedWeight']?.toString() ?? '');
    final weightBridgeNo =
         TextEditingController(text: land['weightBridgeNo']?.toString() ?? '');

    final netController = TextEditingController();
    final finalController = TextEditingController();

    void _recalculateWeights(StateSetter setModalState) {
      final gross = double.tryParse(grossController.text) ?? 0;
      final tare = double.tryParse(tareController.text) ?? 0;
      final rejected = double.tryParse(rejectedController.text) ?? 0;

      double net = gross - tare;
      if (net < 0) net = 0;

      double finalWt = net - rejected;
      if (finalWt < 0) finalWt = 0;

      setModalState(() {
        netController.text = net.toStringAsFixed(2);
        finalController.text = finalWt.toStringAsFixed(2);
      });
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      isDismissible: false,
      enableDrag: false,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            void _pickStartTime() async {
              final picked = await showTimePicker(
                context: context,
                initialTime: _startTime ?? TimeOfDay.now(),
              );
              if (picked != null) {
                setModalState(() => _startTime = picked);
              }
            }

            void _pickEndTime() async {
              final picked = await showTimePicker(
                context: context,
                initialTime: _endTime ?? TimeOfDay.now(),
              );
              if (picked != null) {
                setModalState(() => _endTime = picked);
              }
            }

            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom,
                left: 16,
                right: 16,
                top: 16,
              ),
              child: ListView(
                shrinkWrap: true,
                children: [
                  /// HEADER
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Load Number - ${index + 1}",
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          if (land['grossWeight'] == null) {
                            _newffbList.removeAt(index);
                          }
                          Navigator.pop(context);
                        },
                      ),
                    ],
                  ),

                  const Divider(),

                  /// TIME PICKERS
                  _timeRow(
                      "Weigh Bridge Entry Time", _startTime, _pickStartTime),
                  const SizedBox(height: 8),
                  _timeRow("Weigh Bridge Exit Time", _endTime, _pickEndTime),

                  const SizedBox(height: 16),

                  _buildRowField("Gross Weight", grossController,
                      () => _recalculateWeights(setModalState)),
                  const SizedBox(height: 12),

                  _buildRowField("Tare Weight", tareController,
                      () => _recalculateWeights(setModalState)),
                  const SizedBox(height: 12),

                  _buildRowField("Rejected Weight", rejectedController,
                      () => _recalculateWeights(setModalState)),

                  const SizedBox(height: 12),

                  _buildRowField("Weigh Bridge Acknowledgement No", weightBridgeNo,(){}),

                  const SizedBox(height: 12),
                  const SizedBox(height: 20),

                  _summaryRow("Net Weight", netController.text),
                  _summaryRow("Total Weight", finalController.text),

                  Obx(() => weightcorrect.value
                      ? const Text(
                          "Please update fields accurately",
                          style: TextStyle(color: Colors.red),
                        )
                      : const SizedBox()),

                  const SizedBox(height: 24),

                  ButtonBS(
                    height: 40,
                    borderRadius: 10,
                    title: "Save",
                    backgroundColor: AppColors.primary,
                    textColor: Colors.white,
                    onPressed: () {
                      final gross = double.tryParse(grossController.text) ?? 0;
                      final tare = double.tryParse(tareController.text) ?? 0;
                      final rejected =
                          double.tryParse(rejectedController.text) ?? 0;

                      final net = gross - tare;

                      if (gross <= tare ||
                          gross == 0 ||
                          tare == 0 ||
                          rejected > net ||
                          _startTime == null ||
                          _endTime == null|| weightBridgeNo.text.isEmpty) {
                        weightcorrect.value = true;
                        return;
                      }

                      _newffbList[index]
                        ..['grossWeight'] = gross
                        ..['tareWeight'] = tare
                        ..['rejectedWeight'] = rejected
                        ..['netWeight'] = net
                        ..['finalWeight'] = net - rejected
                        ..['_startTime'] = _startTime!.format(context)
                        ..['_endTime'] = _endTime!.format(context)
                        ..['_startTimeRaw'] = _startTime
                        ..['_endTimeRaw'] = _endTime
                        ..['weightBridgeNo'] = weightBridgeNo;

                      weightcorrect.value = false;
                      Navigator.pop(context);
                      setState(() {});
                    },
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _summaryRow(String title, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title),
        Text("$value kg"),
      ],
    );
  }

  Widget _timeRow(String title, TimeOfDay? time, VoidCallback onTap) {
    return Row(
      children: [
        Text(title),
        const Spacer(),
        GestureDetector(
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 20),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              time?.format(Get.context!) ?? "00:00",
              style: const TextStyle(fontSize: 12),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildRowField(
    String label,
    TextEditingController controller,
    VoidCallback onChanged,
  ) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        hintText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
      ),
      onChanged: (_) => onChanged(),
    );
  }
}
